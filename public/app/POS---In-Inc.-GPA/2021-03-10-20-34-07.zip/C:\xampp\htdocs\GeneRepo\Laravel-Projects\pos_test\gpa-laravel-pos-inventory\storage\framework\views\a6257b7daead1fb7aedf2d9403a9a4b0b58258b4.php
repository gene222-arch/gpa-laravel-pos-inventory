<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>

    <style>
        * {
            font-family: monospace !important;
            line-height: 1.6;
            font-size: 12px;
        }

        .payment-details {
            width: 100%;
            margin-top: 30px;
            text-align: center;
        }
        .payment-details td, .payment-id td {
            padding: 1px 0;
        }

        .payment-id, .billing-details {
            width: 50%;
        }
        .payment-id th, .billing-details th {
            padding: 1px 5px 1px 0;
            text-align: left;
        }
        .payment-id td, .billing-details td
        {
            padding-left: 5px;
            background-color: #dddddd;
            text-align: left;
            width: 30%;
        }

        .payment-details th {
            padding: 4px 0 4px 0;
        }
        td {
            padding: 5px;
        }

        .payment-id {
            margin: 5px 0 50px;
        }

        .billing-details {
            margin: 5px 0 60px;
        }

        .payment-pre-total
        {
            width: 20%;
            margin-left: auto;
            font-size: 12px;
        }

        header {
            font-size: 30px;
        }


        .terms {
            width: 70%;
        }
        .terms .terms-message {
            padding: 3px 4px;
            color: #575656;
            background-color: rgb(145, 209, 218);
        }

        .receipt-details-table {
            width: 20%;
            margin-left: auto;
        }

        .receipt-header
        {
            text-align: center;
            width: 100%;
            font-size: 12px;
        }

        .shop-name
        {
            font-size: 16px !important;
            text-align: center;
        }

        .dotted {
            border: 1px dotted #2c2c2c;
            border-style: none none dotted;
            color: #fff; background-color: #fff;
        }
        .payment-details {
            border-collapse: collapse;
        }

        .payment-title
        {
            border-bottom: 1px dotted #2c2c2c;
            padding-bottom: 20px;
        }

        .payment {
            font-weight: 700;
        }
    </style>
</head>
<body>
    <table class="receipt-header">
        <tbody>
            <tr>
                <td class="shop-name">
                    <?php echo e(Config::get('app.company_name', 'default')); ?>

                </td>
            </tr>
            <tr>
                <td>
                    <?php echo e(Config::get('app.company_address', 'default')); ?>

                </td>
            </tr>
            <tr>
                <td>
                    <?php echo e(Config::get('app.company_contact', 'default')); ?>

                </td>
            </tr>
        </tbody>
    </table>


    <table class="payment-details">
        <thead>
            <tr>
                <th class="payment-title">Description</th>
                <th class="payment-title">Qty</th>
                <th class="payment-title">Price</th>
                <th class="payment-title">Amount</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $paymentDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paymentDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($paymentDetail->product_description); ?></td>
                    <td><?php echo e($paymentDetail->quantity); ?></td>
                    <td><?php echo e('P'. $paymentDetail->unit_price); ?></td>
                    <td><?php echo e('P'. $paymentDetail->sub_total); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <hr class='dotted' style="margin-top: 20px">

    <table class="payment-pre-total">
        <tbody>
            <tr>
                <td>Subtotal</td>
                <td align="right"><?php echo e('P' . $payment->sub_total); ?></td>
            </tr>
            <tr>
                <td>Discount</td>
                <td align="right"><?php echo e('P' . $payment->discount); ?></td>
            </tr>
            <tr>
                <td>(Tax Rate)</td>
                <td align="right"><?php echo e($taxRate); ?></td>
            </tr>
            <tr>
                <td>Tax</td>
                <td align="right"><?php echo e('P' . $payment->tax); ?></td>
            </tr>
        </tbody>
    </table>
    <hr class='dotted'>
    <table class="receipt-details-table">
        <tbody>
            <tr>
                <td>
                    Total
                </td>
                <td align="right" class="payment"><?php echo e('P' . $payment->total); ?></td>
            </tr>
            <tr>
                <td>
                    Cash
                </td>
                <td align="right" class="payment"><?php echo e('P'. $payment->cash); ?></td>
            </tr>
            <tr>
                <td>
                    Balance
                </td>
                <td align="right" class="payment"><?php echo e($payment->change); ?></td>
            </tr>
        </tbody>
    </table>
    <hr class="dotted" style="margin-top: 25px;">
        <p style="text-align: center">Thank you, come again.</p>
    <hr class="dotted">
</body>
</html>
<?php /**PATH C:\xampp\htdocs\GeneRepo\Laravel-Projects\pos_test\gpa-laravel-pos-inventory\resources\views/exports/PDFs/payment.blade.php ENDPATH**/ ?>