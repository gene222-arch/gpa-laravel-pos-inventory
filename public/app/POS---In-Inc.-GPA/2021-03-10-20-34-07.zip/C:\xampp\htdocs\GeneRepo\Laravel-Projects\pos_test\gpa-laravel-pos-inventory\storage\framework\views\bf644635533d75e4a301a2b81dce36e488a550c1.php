<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
        * {
            font-family: Helvetica;
            text-align: center;
        }
    </style>
</head>
<body>

    <table>
        <thead>
            <tr align="center">
                <th align="center"><strong>Purchase order #</strong></th>
                <th colspan="2" align="center"><strong>Product</strong></th>
                <th colspan="2" align="center"><strong>Received</strong></th>
                <th colspan="2" align="center"><strong>Ordered</strong></th>
                <th colspan="2" align="center"><strong>Remaining order</strong></th>
                <th colspan="2" align="center"><strong>Purchase cost</strong></th>
                <th colspan="2" align="center"><strong>Amount</strong></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $purchaseOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchaseOrder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td align="center"><?php echo e($purchaseOrder->id); ?></td>
                    <td colspan="2" align="center"><?php echo e($purchaseOrder->product_description); ?></td>
                    <td colspan="2" align="center"><?php echo e($purchaseOrder->received_quantity); ?></td>
                    <td colspan="2" align="center"><?php echo e($purchaseOrder->ordered_quantity); ?></td>
                    <td colspan="2" align="center"><?php echo e($purchaseOrder->remaining_ordered_quantity); ?></td>
                    <td colspan="2" align="center"><?php echo e($purchaseOrder->purchase_cost); ?></td>
                    <td colspan="2" align="center"><?php echo e($purchaseOrder->amount); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\GeneRepo\Laravel-Projects\pos_test\gpa-laravel-pos-inventory\resources\views/exports/EXCEL-CSVs/purchase-order.blade.php ENDPATH**/ ?>