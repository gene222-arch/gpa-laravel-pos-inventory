
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `access_rights`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `access_rights` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` bigint(20) unsigned NOT NULL,
  `back_office` tinyint(1) NOT NULL,
  `pos` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `access_rights_role_id_foreign` (`role_id`),
  CONSTRAINT `access_rights_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `access_rights` WRITE;
/*!40000 ALTER TABLE `access_rights` DISABLE KEYS */;
INSERT INTO `access_rights` VALUES (1,1,1,1,'2021-03-09 09:44:06',NULL),(2,2,0,1,'2021-03-09 11:46:16','2021-03-09 12:05:15'),(3,3,0,1,'2021-03-09 12:27:04','2021-03-09 12:57:29'),(4,4,0,0,'2021-03-09 12:51:12','2021-03-09 12:51:12');
/*!40000 ALTER TABLE `access_rights` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `bad_order_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bad_order_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `bad_order_id` bigint(20) unsigned NOT NULL,
  `purchase_order_details_id` bigint(20) unsigned DEFAULT NULL,
  `product_id` bigint(20) unsigned DEFAULT NULL,
  `defect` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int(10) unsigned NOT NULL DEFAULT 1,
  `price` double(20,2) unsigned NOT NULL DEFAULT 0.00,
  `unit_of_measurement` char(15) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pcs',
  `amount` double(20,2) unsigned NOT NULL DEFAULT 0.00,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `bad_order_details_purchase_order_details_id_product_id_unique` (`purchase_order_details_id`,`product_id`),
  KEY `bad_order_details_bad_order_id_foreign` (`bad_order_id`),
  KEY `bad_order_details_product_id_foreign` (`product_id`),
  CONSTRAINT `bad_order_details_bad_order_id_foreign` FOREIGN KEY (`bad_order_id`) REFERENCES `bad_orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `bad_order_details_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL,
  CONSTRAINT `bad_order_details_purchase_order_details_id_foreign` FOREIGN KEY (`purchase_order_details_id`) REFERENCES `purchase_order_details` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `bad_order_details` WRITE;
/*!40000 ALTER TABLE `bad_order_details` DISABLE KEYS */;
INSERT INTO `bad_order_details` VALUES (1,1,1,1,'Marketing Defects',2,2.00,'each',4.00,'2021-03-09 13:28:46','2021-03-09 13:28:46'),(2,2,2,1,'Design Defects',21,20.00,'each',420.00,'2021-03-10 10:03:06','2021-03-10 10:03:06');
/*!40000 ALTER TABLE `bad_order_details` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `bad_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bad_orders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `purchase_order_id` bigint(20) unsigned NOT NULL,
  `status` char(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `bad_orders_purchase_order_id_foreign` (`purchase_order_id`),
  CONSTRAINT `bad_orders_purchase_order_id_foreign` FOREIGN KEY (`purchase_order_id`) REFERENCES `purchase_order` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `bad_orders` WRITE;
/*!40000 ALTER TABLE `bad_orders` DISABLE KEYS */;
INSERT INTO `bad_orders` VALUES (1,1,1,'Pending','2021-03-09 13:28:46','2021-03-09 13:28:46'),(2,1,2,'Pending','2021-03-10 10:03:06','2021-03-10 10:03:06');
/*!40000 ALTER TABLE `bad_orders` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'Shoes','2021-03-09 10:54:18','2021-03-09 10:54:18'),(3,'Bike','2021-03-09 10:56:22','2021-03-09 10:56:22');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` char(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `province` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `postal_code` char(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `customers_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (1,'Walk in','NULL','NULL','NULL','NULL','NULL','NULL','NULL','2021-03-09 10:34:27',NULL),(3,'Barinie','genephillip222@gmail.com','12311231234','Canlubang','Calamba','Laguna','1232','Armenia','2021-03-09 13:05:10',NULL);
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `discounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `discounts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `percentage` double(5,2) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `discounts_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `discounts` WRITE;
/*!40000 ALTER TABLE `discounts` DISABLE KEYS */;
INSERT INTO `discounts` VALUES (1,'Summer',10.00,'2021-03-09 11:23:43',NULL),(2,'UA freeze',21.00,'2021-03-09 11:26:11',NULL),(3,'Feblove',14.00,'2021-03-09 11:26:37',NULL),(4,'Spring',22.00,'2021-03-09 11:27:00','2021-03-09 11:28:40');
/*!40000 ALTER TABLE `discounts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employees` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` char(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `employees_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
INSERT INTO `employees` VALUES (1,'Administrator','genephillip222@gmail.com','154898456984','Super Admin','2021-03-09 12:08:38',NULL),(2,'James','james@yahoo.com','12312312322','Manager','2021-03-09 12:26:09','2021-03-09 12:57:47'),(3,'John','john@yahoo.com','11111111111','Cashier','2021-03-09 12:39:42','2021-03-09 12:39:42'),(4,'Shimmy','shimmy@yahoo.com','11111112352','Cashier','2021-03-09 12:42:45','2021-03-09 12:42:45');
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
INSERT INTO `failed_jobs` VALUES (1,'aacbeeca-a3f0-40d5-9a94-cf9ab54f8950','database','default','{\"uuid\":\"aacbeeca-a3f0-40d5-9a94-cf9ab54f8950\",\"displayName\":\"App\\\\Notifications\\\\InvoiceNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"backoff\":\"\",\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":16:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":4:{s:5:\\\"class\\\";s:19:\\\"App\\\\Models\\\\Customer\\\";s:2:\\\"id\\\";a:1:{i:0;i:1;}s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";}s:12:\\\"notification\\\";O:37:\\\"App\\\\Notifications\\\\InvoiceNotification\\\":14:{s:9:\\\"invoiceId\\\";i:20;s:7:\\\"dueDate\\\";s:16:\\\"4 weeks from now\\\";s:8:\\\"fileName\\\";s:36:\\\"invoice-2021-03-10-1615402644-20.pdf\\\";s:2:\\\"id\\\";s:36:\\\"a2f86565-5b8f-47bd-aa78-514f7a45d812\\\";s:6:\\\"locale\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}s:8:\\\"channels\\\";a:1:{i:0;s:4:\\\"mail\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}\"}}','Swift_RfcComplianceException: Address in mailbox given [NULL] does not comply with RFC 2822, 3.6.2. in C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Mime\\Headers\\MailboxHeader.php:355\nStack trace:\n#0 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Mime\\Headers\\MailboxHeader.php(272): Swift_Mime_Headers_MailboxHeader->assertValidAddress(\'NULL\')\n#1 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Mime\\Headers\\MailboxHeader.php(117): Swift_Mime_Headers_MailboxHeader->normalizeMailboxes(Array)\n#2 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Mime\\Headers\\MailboxHeader.php(74): Swift_Mime_Headers_MailboxHeader->setNameAddresses(Array)\n#3 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Mime\\SimpleHeaderFactory.php(61): Swift_Mime_Headers_MailboxHeader->setFieldBodyModel(Array)\n#4 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Mime\\SimpleHeaderSet.php(71): Swift_Mime_SimpleHeaderFactory->createMailboxHeader(\'To\', Array)\n#5 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Mime\\SimpleMessage.php(323): Swift_Mime_SimpleHeaderSet->addMailboxHeader(\'To\', Array)\n#6 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Mail\\Message.php(162): Swift_Mime_SimpleMessage->setTo(Array, NULL)\n#7 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Mail\\Message.php(98): Illuminate\\Mail\\Message->addAddresses(Array, NULL, \'To\')\n#8 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Notifications\\Channels\\MailChannel.php(163): Illuminate\\Mail\\Message->to(Array)\n#9 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Notifications\\Channels\\MailChannel.php(135): Illuminate\\Notifications\\Channels\\MailChannel->addressMessage(Object(Illuminate\\Mail\\Message), Object(App\\Models\\Customer), Object(App\\Notifications\\InvoiceNotification), Object(Illuminate\\Notifications\\Messages\\MailMessage))\n#10 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Notifications\\Channels\\MailChannel.php(80): Illuminate\\Notifications\\Channels\\MailChannel->buildMessage(Object(Illuminate\\Mail\\Message), Object(App\\Models\\Customer), Object(App\\Notifications\\InvoiceNotification), Object(Illuminate\\Notifications\\Messages\\MailMessage))\n#11 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Mail\\Mailer.php(271): Illuminate\\Notifications\\Channels\\MailChannel->Illuminate\\Notifications\\Channels\\{closure}(Object(Illuminate\\Mail\\Message))\n#12 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Notifications\\Channels\\MailChannel.php(65): Illuminate\\Mail\\Mailer->send(Object(Illuminate\\Support\\HtmlString), Array, Object(Closure))\n#13 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Notifications\\NotificationSender.php(148): Illuminate\\Notifications\\Channels\\MailChannel->send(Object(App\\Models\\Customer), Object(App\\Notifications\\InvoiceNotification))\n#14 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Notifications\\NotificationSender.php(106): Illuminate\\Notifications\\NotificationSender->sendToNotifiable(Object(App\\Models\\Customer), \'dec85540-d1c5-4...\', Object(App\\Notifications\\InvoiceNotification), \'mail\')\n#15 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Support\\Traits\\Localizable.php(19): Illuminate\\Notifications\\NotificationSender->Illuminate\\Notifications\\{closure}()\n#16 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Notifications\\NotificationSender.php(109): Illuminate\\Notifications\\NotificationSender->withLocale(NULL, Object(Closure))\n#17 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Notifications\\ChannelManager.php(54): Illuminate\\Notifications\\NotificationSender->sendNow(Object(Illuminate\\Database\\Eloquent\\Collection), Object(App\\Notifications\\InvoiceNotification), Array)\n#18 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Notifications\\SendQueuedNotifications.php(104): Illuminate\\Notifications\\ChannelManager->sendNow(Object(Illuminate\\Database\\Eloquent\\Collection), Object(App\\Notifications\\InvoiceNotification), Array)\n#19 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(36): Illuminate\\Notifications\\SendQueuedNotifications->handle(Object(Illuminate\\Notifications\\ChannelManager))\n#20 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\Util.php(40): Illuminate\\Container\\BoundMethod::Illuminate\\Container\\{closure}()\n#21 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(93): Illuminate\\Container\\Util::unwrapIfClosure(Object(Closure))\n#22 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(37): Illuminate\\Container\\BoundMethod::callBoundMethod(Object(Illuminate\\Foundation\\Application), Array, Object(Closure))\n#23 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\Container.php(610): Illuminate\\Container\\BoundMethod::call(Object(Illuminate\\Foundation\\Application), Array, Array, NULL)\n#24 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Bus\\Dispatcher.php(128): Illuminate\\Container\\Container->call(Array)\n#25 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(128): Illuminate\\Bus\\Dispatcher->Illuminate\\Bus\\{closure}(Object(Illuminate\\Notifications\\SendQueuedNotifications))\n#26 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(103): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Notifications\\SendQueuedNotifications))\n#27 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Bus\\Dispatcher.php(132): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#28 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\CallQueuedHandler.php(118): Illuminate\\Bus\\Dispatcher->dispatchNow(Object(Illuminate\\Notifications\\SendQueuedNotifications), false)\n#29 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(128): Illuminate\\Queue\\CallQueuedHandler->Illuminate\\Queue\\{closure}(Object(Illuminate\\Notifications\\SendQueuedNotifications))\n#30 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(103): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Notifications\\SendQueuedNotifications))\n#31 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\CallQueuedHandler.php(120): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#32 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\CallQueuedHandler.php(70): Illuminate\\Queue\\CallQueuedHandler->dispatchThroughMiddleware(Object(Illuminate\\Queue\\Jobs\\DatabaseJob), Object(Illuminate\\Notifications\\SendQueuedNotifications))\n#33 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Jobs\\Job.php(98): Illuminate\\Queue\\CallQueuedHandler->call(Object(Illuminate\\Queue\\Jobs\\DatabaseJob), Array)\n#34 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Worker.php(406): Illuminate\\Queue\\Jobs\\Job->fire()\n#35 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Worker.php(356): Illuminate\\Queue\\Worker->process(\'database\', Object(Illuminate\\Queue\\Jobs\\DatabaseJob), Object(Illuminate\\Queue\\WorkerOptions))\n#36 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Worker.php(158): Illuminate\\Queue\\Worker->runJob(Object(Illuminate\\Queue\\Jobs\\DatabaseJob), \'database\', Object(Illuminate\\Queue\\WorkerOptions))\n#37 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Console\\WorkCommand.php(116): Illuminate\\Queue\\Worker->daemon(\'database\', \'default\', Object(Illuminate\\Queue\\WorkerOptions))\n#38 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Console\\WorkCommand.php(100): Illuminate\\Queue\\Console\\WorkCommand->runWorker(\'database\', \'default\')\n#39 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(36): Illuminate\\Queue\\Console\\WorkCommand->handle()\n#40 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\Util.php(40): Illuminate\\Container\\BoundMethod::Illuminate\\Container\\{closure}()\n#41 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(93): Illuminate\\Container\\Util::unwrapIfClosure(Object(Closure))\n#42 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(37): Illuminate\\Container\\BoundMethod::callBoundMethod(Object(Illuminate\\Foundation\\Application), Array, Object(Closure))\n#43 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\Container.php(610): Illuminate\\Container\\BoundMethod::call(Object(Illuminate\\Foundation\\Application), Array, Array, NULL)\n#44 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Console\\Command.php(136): Illuminate\\Container\\Container->call(Array)\n#45 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\symfony\\console\\Command\\Command.php(256): Illuminate\\Console\\Command->execute(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Illuminate\\Console\\OutputStyle))\n#46 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Console\\Command.php(121): Symfony\\Component\\Console\\Command\\Command->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Illuminate\\Console\\OutputStyle))\n#47 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\symfony\\console\\Application.php(971): Illuminate\\Console\\Command->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#48 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\symfony\\console\\Application.php(290): Symfony\\Component\\Console\\Application->doRunCommand(Object(Illuminate\\Queue\\Console\\WorkCommand), Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#49 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\symfony\\console\\Application.php(166): Symfony\\Component\\Console\\Application->doRun(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#50 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Console\\Application.php(93): Symfony\\Component\\Console\\Application->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#51 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Console\\Kernel.php(129): Illuminate\\Console\\Application->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#52 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\artisan(37): Illuminate\\Foundation\\Console\\Kernel->handle(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#53 {main}','2021-03-10 10:57:40'),(2,'49f19ea8-f7c1-4ed3-82c5-11511e48b428','database','default','{\"uuid\":\"49f19ea8-f7c1-4ed3-82c5-11511e48b428\",\"displayName\":\"App\\\\Jobs\\\\QueueCustomInvoiceNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"App\\\\Jobs\\\\QueueCustomInvoiceNotification\",\"command\":\"O:39:\\\"App\\\\Jobs\\\\QueueCustomInvoiceNotification\\\":15:{s:12:\\\"customerName\\\";s:4:\\\"Gene\\\";s:13:\\\"customerEmail\\\";s:24:\\\"genephillip222@gmail.com\\\";s:9:\\\"invoiceId\\\";i:22;s:11:\\\"paymentDate\\\";s:19:\\\"2021-04-09 19:12:56\\\";s:8:\\\"fileName\\\";s:36:\\\"invoice-2021-03-10-1615403576-22.pdf\\\";s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";O:25:\\\"Illuminate\\\\Support\\\\Carbon\\\":3:{s:4:\\\"date\\\";s:26:\\\"2021-03-10 19:13:09.070437\\\";s:13:\\\"timezone_type\\\";i:3;s:8:\\\"timezone\\\";s:3:\\\"UTC\\\";}s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}\"}}','ErrorException: Undefined property: App\\Jobs\\QueueCustomInvoiceNotification::$email in C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\app\\Jobs\\QueueCustomInvoiceNotification.php:46\nStack trace:\n#0 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\app\\Jobs\\QueueCustomInvoiceNotification.php(46): Illuminate\\Foundation\\Bootstrap\\HandleExceptions->handleError(2, \'Undefined prope...\', \'C:\\\\xampp\\\\htdocs...\', 46)\n#1 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(36): App\\Jobs\\QueueCustomInvoiceNotification->handle()\n#2 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\Util.php(40): Illuminate\\Container\\BoundMethod::Illuminate\\Container\\{closure}()\n#3 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(93): Illuminate\\Container\\Util::unwrapIfClosure(Object(Closure))\n#4 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(37): Illuminate\\Container\\BoundMethod::callBoundMethod(Object(Illuminate\\Foundation\\Application), Array, Object(Closure))\n#5 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\Container.php(610): Illuminate\\Container\\BoundMethod::call(Object(Illuminate\\Foundation\\Application), Array, Array, NULL)\n#6 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Bus\\Dispatcher.php(128): Illuminate\\Container\\Container->call(Array)\n#7 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(128): Illuminate\\Bus\\Dispatcher->Illuminate\\Bus\\{closure}(Object(App\\Jobs\\QueueCustomInvoiceNotification))\n#8 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(103): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(App\\Jobs\\QueueCustomInvoiceNotification))\n#9 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Bus\\Dispatcher.php(132): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#10 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\CallQueuedHandler.php(118): Illuminate\\Bus\\Dispatcher->dispatchNow(Object(App\\Jobs\\QueueCustomInvoiceNotification), false)\n#11 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(128): Illuminate\\Queue\\CallQueuedHandler->Illuminate\\Queue\\{closure}(Object(App\\Jobs\\QueueCustomInvoiceNotification))\n#12 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(103): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(App\\Jobs\\QueueCustomInvoiceNotification))\n#13 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\CallQueuedHandler.php(120): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#14 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\CallQueuedHandler.php(70): Illuminate\\Queue\\CallQueuedHandler->dispatchThroughMiddleware(Object(Illuminate\\Queue\\Jobs\\DatabaseJob), Object(App\\Jobs\\QueueCustomInvoiceNotification))\n#15 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Jobs\\Job.php(98): Illuminate\\Queue\\CallQueuedHandler->call(Object(Illuminate\\Queue\\Jobs\\DatabaseJob), Array)\n#16 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Worker.php(406): Illuminate\\Queue\\Jobs\\Job->fire()\n#17 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Worker.php(356): Illuminate\\Queue\\Worker->process(\'database\', Object(Illuminate\\Queue\\Jobs\\DatabaseJob), Object(Illuminate\\Queue\\WorkerOptions))\n#18 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Worker.php(158): Illuminate\\Queue\\Worker->runJob(Object(Illuminate\\Queue\\Jobs\\DatabaseJob), \'database\', Object(Illuminate\\Queue\\WorkerOptions))\n#19 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Console\\WorkCommand.php(116): Illuminate\\Queue\\Worker->daemon(\'database\', \'default\', Object(Illuminate\\Queue\\WorkerOptions))\n#20 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Console\\WorkCommand.php(100): Illuminate\\Queue\\Console\\WorkCommand->runWorker(\'database\', \'default\')\n#21 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(36): Illuminate\\Queue\\Console\\WorkCommand->handle()\n#22 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\Util.php(40): Illuminate\\Container\\BoundMethod::Illuminate\\Container\\{closure}()\n#23 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(93): Illuminate\\Container\\Util::unwrapIfClosure(Object(Closure))\n#24 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(37): Illuminate\\Container\\BoundMethod::callBoundMethod(Object(Illuminate\\Foundation\\Application), Array, Object(Closure))\n#25 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\Container.php(610): Illuminate\\Container\\BoundMethod::call(Object(Illuminate\\Foundation\\Application), Array, Array, NULL)\n#26 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Console\\Command.php(136): Illuminate\\Container\\Container->call(Array)\n#27 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\symfony\\console\\Command\\Command.php(256): Illuminate\\Console\\Command->execute(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Illuminate\\Console\\OutputStyle))\n#28 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Console\\Command.php(121): Symfony\\Component\\Console\\Command\\Command->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Illuminate\\Console\\OutputStyle))\n#29 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\symfony\\console\\Application.php(971): Illuminate\\Console\\Command->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#30 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\symfony\\console\\Application.php(290): Symfony\\Component\\Console\\Application->doRunCommand(Object(Illuminate\\Queue\\Console\\WorkCommand), Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#31 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\symfony\\console\\Application.php(166): Symfony\\Component\\Console\\Application->doRun(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#32 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Console\\Application.php(93): Symfony\\Component\\Console\\Application->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#33 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Console\\Kernel.php(129): Illuminate\\Console\\Application->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#34 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\artisan(37): Illuminate\\Foundation\\Console\\Kernel->handle(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#35 {main}','2021-03-10 11:13:11'),(3,'89e36b0a-1e20-4467-8c8e-2306397b5c24','database','default','{\"uuid\":\"89e36b0a-1e20-4467-8c8e-2306397b5c24\",\"displayName\":\"App\\\\Jobs\\\\QueueCustomInvoiceNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"App\\\\Jobs\\\\QueueCustomInvoiceNotification\",\"command\":\"O:39:\\\"App\\\\Jobs\\\\QueueCustomInvoiceNotification\\\":15:{s:12:\\\"customerName\\\";s:4:\\\"Gene\\\";s:13:\\\"customerEmail\\\";s:24:\\\"genephillip222@gmail.com\\\";s:9:\\\"invoiceId\\\";i:23;s:11:\\\"paymentDate\\\";s:19:\\\"2021-04-09 19:14:33\\\";s:8:\\\"fileName\\\";s:36:\\\"invoice-2021-03-10-1615403673-23.pdf\\\";s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";O:25:\\\"Illuminate\\\\Support\\\\Carbon\\\":3:{s:4:\\\"date\\\";s:26:\\\"2021-03-10 19:14:46.025506\\\";s:13:\\\"timezone_type\\\";i:3;s:8:\\\"timezone\\\";s:3:\\\"UTC\\\";}s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}\"}}','ErrorException: Undefined property: App\\Jobs\\QueueCustomInvoiceNotification::$email in C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\app\\Jobs\\QueueCustomInvoiceNotification.php:46\nStack trace:\n#0 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\app\\Jobs\\QueueCustomInvoiceNotification.php(46): Illuminate\\Foundation\\Bootstrap\\HandleExceptions->handleError(2, \'Undefined prope...\', \'C:\\\\xampp\\\\htdocs...\', 46)\n#1 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(36): App\\Jobs\\QueueCustomInvoiceNotification->handle()\n#2 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\Util.php(40): Illuminate\\Container\\BoundMethod::Illuminate\\Container\\{closure}()\n#3 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(93): Illuminate\\Container\\Util::unwrapIfClosure(Object(Closure))\n#4 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(37): Illuminate\\Container\\BoundMethod::callBoundMethod(Object(Illuminate\\Foundation\\Application), Array, Object(Closure))\n#5 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\Container.php(610): Illuminate\\Container\\BoundMethod::call(Object(Illuminate\\Foundation\\Application), Array, Array, NULL)\n#6 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Bus\\Dispatcher.php(128): Illuminate\\Container\\Container->call(Array)\n#7 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(128): Illuminate\\Bus\\Dispatcher->Illuminate\\Bus\\{closure}(Object(App\\Jobs\\QueueCustomInvoiceNotification))\n#8 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(103): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(App\\Jobs\\QueueCustomInvoiceNotification))\n#9 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Bus\\Dispatcher.php(132): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#10 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\CallQueuedHandler.php(118): Illuminate\\Bus\\Dispatcher->dispatchNow(Object(App\\Jobs\\QueueCustomInvoiceNotification), false)\n#11 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(128): Illuminate\\Queue\\CallQueuedHandler->Illuminate\\Queue\\{closure}(Object(App\\Jobs\\QueueCustomInvoiceNotification))\n#12 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(103): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(App\\Jobs\\QueueCustomInvoiceNotification))\n#13 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\CallQueuedHandler.php(120): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#14 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\CallQueuedHandler.php(70): Illuminate\\Queue\\CallQueuedHandler->dispatchThroughMiddleware(Object(Illuminate\\Queue\\Jobs\\DatabaseJob), Object(App\\Jobs\\QueueCustomInvoiceNotification))\n#15 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Jobs\\Job.php(98): Illuminate\\Queue\\CallQueuedHandler->call(Object(Illuminate\\Queue\\Jobs\\DatabaseJob), Array)\n#16 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Worker.php(406): Illuminate\\Queue\\Jobs\\Job->fire()\n#17 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Worker.php(356): Illuminate\\Queue\\Worker->process(\'database\', Object(Illuminate\\Queue\\Jobs\\DatabaseJob), Object(Illuminate\\Queue\\WorkerOptions))\n#18 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Worker.php(158): Illuminate\\Queue\\Worker->runJob(Object(Illuminate\\Queue\\Jobs\\DatabaseJob), \'database\', Object(Illuminate\\Queue\\WorkerOptions))\n#19 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Console\\WorkCommand.php(116): Illuminate\\Queue\\Worker->daemon(\'database\', \'default\', Object(Illuminate\\Queue\\WorkerOptions))\n#20 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Console\\WorkCommand.php(100): Illuminate\\Queue\\Console\\WorkCommand->runWorker(\'database\', \'default\')\n#21 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(36): Illuminate\\Queue\\Console\\WorkCommand->handle()\n#22 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\Util.php(40): Illuminate\\Container\\BoundMethod::Illuminate\\Container\\{closure}()\n#23 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(93): Illuminate\\Container\\Util::unwrapIfClosure(Object(Closure))\n#24 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(37): Illuminate\\Container\\BoundMethod::callBoundMethod(Object(Illuminate\\Foundation\\Application), Array, Object(Closure))\n#25 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\Container.php(610): Illuminate\\Container\\BoundMethod::call(Object(Illuminate\\Foundation\\Application), Array, Array, NULL)\n#26 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Console\\Command.php(136): Illuminate\\Container\\Container->call(Array)\n#27 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\symfony\\console\\Command\\Command.php(256): Illuminate\\Console\\Command->execute(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Illuminate\\Console\\OutputStyle))\n#28 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Console\\Command.php(121): Symfony\\Component\\Console\\Command\\Command->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Illuminate\\Console\\OutputStyle))\n#29 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\symfony\\console\\Application.php(971): Illuminate\\Console\\Command->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#30 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\symfony\\console\\Application.php(290): Symfony\\Component\\Console\\Application->doRunCommand(Object(Illuminate\\Queue\\Console\\WorkCommand), Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#31 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\symfony\\console\\Application.php(166): Symfony\\Component\\Console\\Application->doRun(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#32 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Console\\Application.php(93): Symfony\\Component\\Console\\Application->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#33 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Console\\Kernel.php(129): Illuminate\\Console\\Application->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#34 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\artisan(37): Illuminate\\Foundation\\Console\\Kernel->handle(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#35 {main}','2021-03-10 11:14:49'),(4,'a831fada-ecad-4a77-8a3f-9bd618dc5b1b','database','default','{\"uuid\":\"a831fada-ecad-4a77-8a3f-9bd618dc5b1b\",\"displayName\":\"App\\\\Jobs\\\\QueueCustomInvoiceNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"App\\\\Jobs\\\\QueueCustomInvoiceNotification\",\"command\":\"O:39:\\\"App\\\\Jobs\\\\QueueCustomInvoiceNotification\\\":15:{s:12:\\\"customerName\\\";s:4:\\\"Gene\\\";s:13:\\\"customerEmail\\\";s:24:\\\"genephillip222@gmail.com\\\";s:9:\\\"invoiceId\\\";i:24;s:11:\\\"paymentDate\\\";s:19:\\\"2021-04-09 19:21:31\\\";s:8:\\\"fileName\\\";s:36:\\\"invoice-2021-03-10-1615404091-24.pdf\\\";s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";O:25:\\\"Illuminate\\\\Support\\\\Carbon\\\":3:{s:4:\\\"date\\\";s:26:\\\"2021-03-10 19:21:43.634833\\\";s:13:\\\"timezone_type\\\";i:3;s:8:\\\"timezone\\\";s:3:\\\"UTC\\\";}s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}\"}}','ErrorException: Undefined property: App\\Jobs\\QueueCustomInvoiceNotification::$email in C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\app\\Jobs\\QueueCustomInvoiceNotification.php:46\nStack trace:\n#0 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\app\\Jobs\\QueueCustomInvoiceNotification.php(46): Illuminate\\Foundation\\Bootstrap\\HandleExceptions->handleError(2, \'Undefined prope...\', \'C:\\\\xampp\\\\htdocs...\', 46)\n#1 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(36): App\\Jobs\\QueueCustomInvoiceNotification->handle()\n#2 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\Util.php(40): Illuminate\\Container\\BoundMethod::Illuminate\\Container\\{closure}()\n#3 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(93): Illuminate\\Container\\Util::unwrapIfClosure(Object(Closure))\n#4 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(37): Illuminate\\Container\\BoundMethod::callBoundMethod(Object(Illuminate\\Foundation\\Application), Array, Object(Closure))\n#5 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\Container.php(610): Illuminate\\Container\\BoundMethod::call(Object(Illuminate\\Foundation\\Application), Array, Array, NULL)\n#6 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Bus\\Dispatcher.php(128): Illuminate\\Container\\Container->call(Array)\n#7 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(128): Illuminate\\Bus\\Dispatcher->Illuminate\\Bus\\{closure}(Object(App\\Jobs\\QueueCustomInvoiceNotification))\n#8 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(103): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(App\\Jobs\\QueueCustomInvoiceNotification))\n#9 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Bus\\Dispatcher.php(132): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#10 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\CallQueuedHandler.php(118): Illuminate\\Bus\\Dispatcher->dispatchNow(Object(App\\Jobs\\QueueCustomInvoiceNotification), false)\n#11 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(128): Illuminate\\Queue\\CallQueuedHandler->Illuminate\\Queue\\{closure}(Object(App\\Jobs\\QueueCustomInvoiceNotification))\n#12 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(103): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(App\\Jobs\\QueueCustomInvoiceNotification))\n#13 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\CallQueuedHandler.php(120): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#14 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\CallQueuedHandler.php(70): Illuminate\\Queue\\CallQueuedHandler->dispatchThroughMiddleware(Object(Illuminate\\Queue\\Jobs\\DatabaseJob), Object(App\\Jobs\\QueueCustomInvoiceNotification))\n#15 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Jobs\\Job.php(98): Illuminate\\Queue\\CallQueuedHandler->call(Object(Illuminate\\Queue\\Jobs\\DatabaseJob), Array)\n#16 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Worker.php(406): Illuminate\\Queue\\Jobs\\Job->fire()\n#17 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Worker.php(356): Illuminate\\Queue\\Worker->process(\'database\', Object(Illuminate\\Queue\\Jobs\\DatabaseJob), Object(Illuminate\\Queue\\WorkerOptions))\n#18 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Worker.php(158): Illuminate\\Queue\\Worker->runJob(Object(Illuminate\\Queue\\Jobs\\DatabaseJob), \'database\', Object(Illuminate\\Queue\\WorkerOptions))\n#19 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Console\\WorkCommand.php(116): Illuminate\\Queue\\Worker->daemon(\'database\', \'default\', Object(Illuminate\\Queue\\WorkerOptions))\n#20 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Console\\WorkCommand.php(100): Illuminate\\Queue\\Console\\WorkCommand->runWorker(\'database\', \'default\')\n#21 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(36): Illuminate\\Queue\\Console\\WorkCommand->handle()\n#22 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\Util.php(40): Illuminate\\Container\\BoundMethod::Illuminate\\Container\\{closure}()\n#23 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(93): Illuminate\\Container\\Util::unwrapIfClosure(Object(Closure))\n#24 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(37): Illuminate\\Container\\BoundMethod::callBoundMethod(Object(Illuminate\\Foundation\\Application), Array, Object(Closure))\n#25 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\Container.php(610): Illuminate\\Container\\BoundMethod::call(Object(Illuminate\\Foundation\\Application), Array, Array, NULL)\n#26 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Console\\Command.php(136): Illuminate\\Container\\Container->call(Array)\n#27 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\symfony\\console\\Command\\Command.php(256): Illuminate\\Console\\Command->execute(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Illuminate\\Console\\OutputStyle))\n#28 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Console\\Command.php(121): Symfony\\Component\\Console\\Command\\Command->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Illuminate\\Console\\OutputStyle))\n#29 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\symfony\\console\\Application.php(971): Illuminate\\Console\\Command->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#30 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\symfony\\console\\Application.php(290): Symfony\\Component\\Console\\Application->doRunCommand(Object(Illuminate\\Queue\\Console\\WorkCommand), Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#31 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\symfony\\console\\Application.php(166): Symfony\\Component\\Console\\Application->doRun(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#32 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Console\\Application.php(93): Symfony\\Component\\Console\\Application->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#33 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Console\\Kernel.php(129): Illuminate\\Console\\Application->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#34 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\artisan(37): Illuminate\\Foundation\\Console\\Kernel->handle(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#35 {main}','2021-03-10 11:21:44'),(5,'959b49cc-29cc-4c71-b61c-66e8dff1e07e','database','default','{\"uuid\":\"959b49cc-29cc-4c71-b61c-66e8dff1e07e\",\"displayName\":\"App\\\\Jobs\\\\QueueCustomInvoiceNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"App\\\\Jobs\\\\QueueCustomInvoiceNotification\",\"command\":\"O:39:\\\"App\\\\Jobs\\\\QueueCustomInvoiceNotification\\\":15:{s:12:\\\"customerName\\\";s:4:\\\"Gene\\\";s:13:\\\"customerEmail\\\";s:24:\\\"genephillip222@gmail.com\\\";s:9:\\\"invoiceId\\\";i:25;s:11:\\\"paymentDate\\\";s:19:\\\"2021-04-09 19:24:11\\\";s:8:\\\"fileName\\\";s:36:\\\"invoice-2021-03-10-1615404251-25.pdf\\\";s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";O:25:\\\"Illuminate\\\\Support\\\\Carbon\\\":3:{s:4:\\\"date\\\";s:26:\\\"2021-03-10 19:24:26.334058\\\";s:13:\\\"timezone_type\\\";i:3;s:8:\\\"timezone\\\";s:3:\\\"UTC\\\";}s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}\"}}','ErrorException: Undefined property: App\\Jobs\\QueueCustomInvoiceNotification::$email in C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\app\\Jobs\\QueueCustomInvoiceNotification.php:46\nStack trace:\n#0 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\app\\Jobs\\QueueCustomInvoiceNotification.php(46): Illuminate\\Foundation\\Bootstrap\\HandleExceptions->handleError(2, \'Undefined prope...\', \'C:\\\\xampp\\\\htdocs...\', 46)\n#1 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(36): App\\Jobs\\QueueCustomInvoiceNotification->handle()\n#2 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\Util.php(40): Illuminate\\Container\\BoundMethod::Illuminate\\Container\\{closure}()\n#3 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(93): Illuminate\\Container\\Util::unwrapIfClosure(Object(Closure))\n#4 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(37): Illuminate\\Container\\BoundMethod::callBoundMethod(Object(Illuminate\\Foundation\\Application), Array, Object(Closure))\n#5 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\Container.php(610): Illuminate\\Container\\BoundMethod::call(Object(Illuminate\\Foundation\\Application), Array, Array, NULL)\n#6 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Bus\\Dispatcher.php(128): Illuminate\\Container\\Container->call(Array)\n#7 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(128): Illuminate\\Bus\\Dispatcher->Illuminate\\Bus\\{closure}(Object(App\\Jobs\\QueueCustomInvoiceNotification))\n#8 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(103): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(App\\Jobs\\QueueCustomInvoiceNotification))\n#9 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Bus\\Dispatcher.php(132): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#10 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\CallQueuedHandler.php(118): Illuminate\\Bus\\Dispatcher->dispatchNow(Object(App\\Jobs\\QueueCustomInvoiceNotification), false)\n#11 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(128): Illuminate\\Queue\\CallQueuedHandler->Illuminate\\Queue\\{closure}(Object(App\\Jobs\\QueueCustomInvoiceNotification))\n#12 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(103): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(App\\Jobs\\QueueCustomInvoiceNotification))\n#13 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\CallQueuedHandler.php(120): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#14 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\CallQueuedHandler.php(70): Illuminate\\Queue\\CallQueuedHandler->dispatchThroughMiddleware(Object(Illuminate\\Queue\\Jobs\\DatabaseJob), Object(App\\Jobs\\QueueCustomInvoiceNotification))\n#15 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Jobs\\Job.php(98): Illuminate\\Queue\\CallQueuedHandler->call(Object(Illuminate\\Queue\\Jobs\\DatabaseJob), Array)\n#16 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Worker.php(406): Illuminate\\Queue\\Jobs\\Job->fire()\n#17 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Worker.php(356): Illuminate\\Queue\\Worker->process(\'database\', Object(Illuminate\\Queue\\Jobs\\DatabaseJob), Object(Illuminate\\Queue\\WorkerOptions))\n#18 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Worker.php(158): Illuminate\\Queue\\Worker->runJob(Object(Illuminate\\Queue\\Jobs\\DatabaseJob), \'database\', Object(Illuminate\\Queue\\WorkerOptions))\n#19 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Console\\WorkCommand.php(116): Illuminate\\Queue\\Worker->daemon(\'database\', \'default\', Object(Illuminate\\Queue\\WorkerOptions))\n#20 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Console\\WorkCommand.php(100): Illuminate\\Queue\\Console\\WorkCommand->runWorker(\'database\', \'default\')\n#21 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(36): Illuminate\\Queue\\Console\\WorkCommand->handle()\n#22 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\Util.php(40): Illuminate\\Container\\BoundMethod::Illuminate\\Container\\{closure}()\n#23 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(93): Illuminate\\Container\\Util::unwrapIfClosure(Object(Closure))\n#24 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(37): Illuminate\\Container\\BoundMethod::callBoundMethod(Object(Illuminate\\Foundation\\Application), Array, Object(Closure))\n#25 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\Container.php(610): Illuminate\\Container\\BoundMethod::call(Object(Illuminate\\Foundation\\Application), Array, Array, NULL)\n#26 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Console\\Command.php(136): Illuminate\\Container\\Container->call(Array)\n#27 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\symfony\\console\\Command\\Command.php(256): Illuminate\\Console\\Command->execute(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Illuminate\\Console\\OutputStyle))\n#28 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Console\\Command.php(121): Symfony\\Component\\Console\\Command\\Command->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Illuminate\\Console\\OutputStyle))\n#29 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\symfony\\console\\Application.php(971): Illuminate\\Console\\Command->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#30 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\symfony\\console\\Application.php(290): Symfony\\Component\\Console\\Application->doRunCommand(Object(Illuminate\\Queue\\Console\\WorkCommand), Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#31 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\symfony\\console\\Application.php(166): Symfony\\Component\\Console\\Application->doRun(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#32 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Console\\Application.php(93): Symfony\\Component\\Console\\Application->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#33 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Console\\Kernel.php(129): Illuminate\\Console\\Application->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#34 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\artisan(37): Illuminate\\Foundation\\Console\\Kernel->handle(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#35 {main}','2021-03-10 11:24:28'),(6,'3fb4fde3-44c8-4aca-b925-901037f9d001','database','default','{\"uuid\":\"3fb4fde3-44c8-4aca-b925-901037f9d001\",\"displayName\":\"App\\\\Jobs\\\\QueueCustomInvoiceNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"App\\\\Jobs\\\\QueueCustomInvoiceNotification\",\"command\":\"O:39:\\\"App\\\\Jobs\\\\QueueCustomInvoiceNotification\\\":15:{s:12:\\\"customerName\\\";s:4:\\\"Gene\\\";s:13:\\\"customerEmail\\\";s:24:\\\"genephillip222@gmail.com\\\";s:9:\\\"invoiceId\\\";i:27;s:11:\\\"paymentDate\\\";s:19:\\\"2021-04-09 19:32:19\\\";s:8:\\\"fileName\\\";s:36:\\\"invoice-2021-03-10-1615404739-27.pdf\\\";s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";O:25:\\\"Illuminate\\\\Support\\\\Carbon\\\":3:{s:4:\\\"date\\\";s:26:\\\"2021-03-10 19:32:32.105307\\\";s:13:\\\"timezone_type\\\";i:3;s:8:\\\"timezone\\\";s:3:\\\"UTC\\\";}s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}\"}}','ErrorException: Undefined property: App\\Jobs\\QueueCustomInvoiceNotification::$email in C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\app\\Jobs\\QueueCustomInvoiceNotification.php:46\nStack trace:\n#0 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\app\\Jobs\\QueueCustomInvoiceNotification.php(46): Illuminate\\Foundation\\Bootstrap\\HandleExceptions->handleError(2, \'Undefined prope...\', \'C:\\\\xampp\\\\htdocs...\', 46)\n#1 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(36): App\\Jobs\\QueueCustomInvoiceNotification->handle()\n#2 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\Util.php(40): Illuminate\\Container\\BoundMethod::Illuminate\\Container\\{closure}()\n#3 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(93): Illuminate\\Container\\Util::unwrapIfClosure(Object(Closure))\n#4 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(37): Illuminate\\Container\\BoundMethod::callBoundMethod(Object(Illuminate\\Foundation\\Application), Array, Object(Closure))\n#5 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\Container.php(610): Illuminate\\Container\\BoundMethod::call(Object(Illuminate\\Foundation\\Application), Array, Array, NULL)\n#6 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Bus\\Dispatcher.php(128): Illuminate\\Container\\Container->call(Array)\n#7 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(128): Illuminate\\Bus\\Dispatcher->Illuminate\\Bus\\{closure}(Object(App\\Jobs\\QueueCustomInvoiceNotification))\n#8 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(103): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(App\\Jobs\\QueueCustomInvoiceNotification))\n#9 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Bus\\Dispatcher.php(132): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#10 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\CallQueuedHandler.php(118): Illuminate\\Bus\\Dispatcher->dispatchNow(Object(App\\Jobs\\QueueCustomInvoiceNotification), false)\n#11 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(128): Illuminate\\Queue\\CallQueuedHandler->Illuminate\\Queue\\{closure}(Object(App\\Jobs\\QueueCustomInvoiceNotification))\n#12 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(103): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(App\\Jobs\\QueueCustomInvoiceNotification))\n#13 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\CallQueuedHandler.php(120): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#14 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\CallQueuedHandler.php(70): Illuminate\\Queue\\CallQueuedHandler->dispatchThroughMiddleware(Object(Illuminate\\Queue\\Jobs\\DatabaseJob), Object(App\\Jobs\\QueueCustomInvoiceNotification))\n#15 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Jobs\\Job.php(98): Illuminate\\Queue\\CallQueuedHandler->call(Object(Illuminate\\Queue\\Jobs\\DatabaseJob), Array)\n#16 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Worker.php(406): Illuminate\\Queue\\Jobs\\Job->fire()\n#17 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Worker.php(356): Illuminate\\Queue\\Worker->process(\'database\', Object(Illuminate\\Queue\\Jobs\\DatabaseJob), Object(Illuminate\\Queue\\WorkerOptions))\n#18 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Worker.php(158): Illuminate\\Queue\\Worker->runJob(Object(Illuminate\\Queue\\Jobs\\DatabaseJob), \'database\', Object(Illuminate\\Queue\\WorkerOptions))\n#19 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Console\\WorkCommand.php(116): Illuminate\\Queue\\Worker->daemon(\'database\', \'default\', Object(Illuminate\\Queue\\WorkerOptions))\n#20 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Console\\WorkCommand.php(100): Illuminate\\Queue\\Console\\WorkCommand->runWorker(\'database\', \'default\')\n#21 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(36): Illuminate\\Queue\\Console\\WorkCommand->handle()\n#22 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\Util.php(40): Illuminate\\Container\\BoundMethod::Illuminate\\Container\\{closure}()\n#23 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(93): Illuminate\\Container\\Util::unwrapIfClosure(Object(Closure))\n#24 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(37): Illuminate\\Container\\BoundMethod::callBoundMethod(Object(Illuminate\\Foundation\\Application), Array, Object(Closure))\n#25 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\Container.php(610): Illuminate\\Container\\BoundMethod::call(Object(Illuminate\\Foundation\\Application), Array, Array, NULL)\n#26 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Console\\Command.php(136): Illuminate\\Container\\Container->call(Array)\n#27 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\symfony\\console\\Command\\Command.php(256): Illuminate\\Console\\Command->execute(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Illuminate\\Console\\OutputStyle))\n#28 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Console\\Command.php(121): Symfony\\Component\\Console\\Command\\Command->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Illuminate\\Console\\OutputStyle))\n#29 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\symfony\\console\\Application.php(971): Illuminate\\Console\\Command->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#30 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\symfony\\console\\Application.php(290): Symfony\\Component\\Console\\Application->doRunCommand(Object(Illuminate\\Queue\\Console\\WorkCommand), Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#31 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\symfony\\console\\Application.php(166): Symfony\\Component\\Console\\Application->doRun(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#32 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Console\\Application.php(93): Symfony\\Component\\Console\\Application->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#33 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Console\\Kernel.php(129): Illuminate\\Console\\Application->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#34 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\artisan(37): Illuminate\\Foundation\\Console\\Kernel->handle(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#35 {main}','2021-03-10 11:32:34'),(7,'09596066-c5db-4d59-bf10-add9ee30dfeb','database','default','{\"uuid\":\"09596066-c5db-4d59-bf10-add9ee30dfeb\",\"displayName\":\"App\\\\Jobs\\\\QueueCustomInvoiceNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"App\\\\Jobs\\\\QueueCustomInvoiceNotification\",\"command\":\"O:39:\\\"App\\\\Jobs\\\\QueueCustomInvoiceNotification\\\":15:{s:12:\\\"customerName\\\";s:4:\\\"Gene\\\";s:13:\\\"customerEmail\\\";s:24:\\\"genephillip222@gmail.com\\\";s:9:\\\"invoiceId\\\";i:28;s:11:\\\"paymentDate\\\";s:19:\\\"2021-04-09 19:33:45\\\";s:8:\\\"fileName\\\";s:36:\\\"invoice-2021-03-10-1615404825-28.pdf\\\";s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";O:25:\\\"Illuminate\\\\Support\\\\Carbon\\\":3:{s:4:\\\"date\\\";s:26:\\\"2021-03-10 19:34:02.554754\\\";s:13:\\\"timezone_type\\\";i:3;s:8:\\\"timezone\\\";s:3:\\\"UTC\\\";}s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}\"}}','ErrorException: Undefined property: App\\Jobs\\QueueCustomInvoiceNotification::$email in C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\app\\Jobs\\QueueCustomInvoiceNotification.php:46\nStack trace:\n#0 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\app\\Jobs\\QueueCustomInvoiceNotification.php(46): Illuminate\\Foundation\\Bootstrap\\HandleExceptions->handleError(2, \'Undefined prope...\', \'C:\\\\xampp\\\\htdocs...\', 46)\n#1 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(36): App\\Jobs\\QueueCustomInvoiceNotification->handle()\n#2 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\Util.php(40): Illuminate\\Container\\BoundMethod::Illuminate\\Container\\{closure}()\n#3 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(93): Illuminate\\Container\\Util::unwrapIfClosure(Object(Closure))\n#4 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(37): Illuminate\\Container\\BoundMethod::callBoundMethod(Object(Illuminate\\Foundation\\Application), Array, Object(Closure))\n#5 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\Container.php(610): Illuminate\\Container\\BoundMethod::call(Object(Illuminate\\Foundation\\Application), Array, Array, NULL)\n#6 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Bus\\Dispatcher.php(128): Illuminate\\Container\\Container->call(Array)\n#7 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(128): Illuminate\\Bus\\Dispatcher->Illuminate\\Bus\\{closure}(Object(App\\Jobs\\QueueCustomInvoiceNotification))\n#8 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(103): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(App\\Jobs\\QueueCustomInvoiceNotification))\n#9 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Bus\\Dispatcher.php(132): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#10 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\CallQueuedHandler.php(118): Illuminate\\Bus\\Dispatcher->dispatchNow(Object(App\\Jobs\\QueueCustomInvoiceNotification), false)\n#11 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(128): Illuminate\\Queue\\CallQueuedHandler->Illuminate\\Queue\\{closure}(Object(App\\Jobs\\QueueCustomInvoiceNotification))\n#12 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(103): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(App\\Jobs\\QueueCustomInvoiceNotification))\n#13 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\CallQueuedHandler.php(120): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#14 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\CallQueuedHandler.php(70): Illuminate\\Queue\\CallQueuedHandler->dispatchThroughMiddleware(Object(Illuminate\\Queue\\Jobs\\DatabaseJob), Object(App\\Jobs\\QueueCustomInvoiceNotification))\n#15 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Jobs\\Job.php(98): Illuminate\\Queue\\CallQueuedHandler->call(Object(Illuminate\\Queue\\Jobs\\DatabaseJob), Array)\n#16 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Worker.php(406): Illuminate\\Queue\\Jobs\\Job->fire()\n#17 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Worker.php(356): Illuminate\\Queue\\Worker->process(\'database\', Object(Illuminate\\Queue\\Jobs\\DatabaseJob), Object(Illuminate\\Queue\\WorkerOptions))\n#18 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Worker.php(158): Illuminate\\Queue\\Worker->runJob(Object(Illuminate\\Queue\\Jobs\\DatabaseJob), \'database\', Object(Illuminate\\Queue\\WorkerOptions))\n#19 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Console\\WorkCommand.php(116): Illuminate\\Queue\\Worker->daemon(\'database\', \'default\', Object(Illuminate\\Queue\\WorkerOptions))\n#20 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Console\\WorkCommand.php(100): Illuminate\\Queue\\Console\\WorkCommand->runWorker(\'database\', \'default\')\n#21 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(36): Illuminate\\Queue\\Console\\WorkCommand->handle()\n#22 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\Util.php(40): Illuminate\\Container\\BoundMethod::Illuminate\\Container\\{closure}()\n#23 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(93): Illuminate\\Container\\Util::unwrapIfClosure(Object(Closure))\n#24 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(37): Illuminate\\Container\\BoundMethod::callBoundMethod(Object(Illuminate\\Foundation\\Application), Array, Object(Closure))\n#25 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\Container.php(610): Illuminate\\Container\\BoundMethod::call(Object(Illuminate\\Foundation\\Application), Array, Array, NULL)\n#26 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Console\\Command.php(136): Illuminate\\Container\\Container->call(Array)\n#27 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\symfony\\console\\Command\\Command.php(256): Illuminate\\Console\\Command->execute(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Illuminate\\Console\\OutputStyle))\n#28 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Console\\Command.php(121): Symfony\\Component\\Console\\Command\\Command->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Illuminate\\Console\\OutputStyle))\n#29 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\symfony\\console\\Application.php(971): Illuminate\\Console\\Command->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#30 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\symfony\\console\\Application.php(290): Symfony\\Component\\Console\\Application->doRunCommand(Object(Illuminate\\Queue\\Console\\WorkCommand), Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#31 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\symfony\\console\\Application.php(166): Symfony\\Component\\Console\\Application->doRun(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#32 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Console\\Application.php(93): Symfony\\Component\\Console\\Application->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#33 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Console\\Kernel.php(129): Illuminate\\Console\\Application->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#34 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\artisan(37): Illuminate\\Foundation\\Console\\Kernel->handle(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#35 {main}','2021-03-10 11:34:04'),(8,'bac266ea-b0f9-4b2d-ba8e-ffc6d6461585','database','default','{\"uuid\":\"bac266ea-b0f9-4b2d-ba8e-ffc6d6461585\",\"displayName\":\"App\\\\Jobs\\\\QueueCustomInvoiceNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"App\\\\Jobs\\\\QueueCustomInvoiceNotification\",\"command\":\"O:39:\\\"App\\\\Jobs\\\\QueueCustomInvoiceNotification\\\":15:{s:12:\\\"customerName\\\";s:4:\\\"Gene\\\";s:13:\\\"customerEmail\\\";s:24:\\\"genephillip222@gmail.com\\\";s:9:\\\"invoiceId\\\";i:29;s:11:\\\"paymentDate\\\";s:19:\\\"2021-04-09 19:37:53\\\";s:8:\\\"fileName\\\";s:36:\\\"invoice-2021-03-10-1615405073-29.pdf\\\";s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";O:25:\\\"Illuminate\\\\Support\\\\Carbon\\\":3:{s:4:\\\"date\\\";s:26:\\\"2021-03-10 19:38:07.233306\\\";s:13:\\\"timezone_type\\\";i:3;s:8:\\\"timezone\\\";s:3:\\\"UTC\\\";}s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}\"}}','ErrorException: Undefined property: App\\Jobs\\QueueCustomInvoiceNotification::$email in C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\app\\Jobs\\QueueCustomInvoiceNotification.php:46\nStack trace:\n#0 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\app\\Jobs\\QueueCustomInvoiceNotification.php(46): Illuminate\\Foundation\\Bootstrap\\HandleExceptions->handleError(2, \'Undefined prope...\', \'C:\\\\xampp\\\\htdocs...\', 46)\n#1 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(36): App\\Jobs\\QueueCustomInvoiceNotification->handle()\n#2 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\Util.php(40): Illuminate\\Container\\BoundMethod::Illuminate\\Container\\{closure}()\n#3 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(93): Illuminate\\Container\\Util::unwrapIfClosure(Object(Closure))\n#4 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(37): Illuminate\\Container\\BoundMethod::callBoundMethod(Object(Illuminate\\Foundation\\Application), Array, Object(Closure))\n#5 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\Container.php(610): Illuminate\\Container\\BoundMethod::call(Object(Illuminate\\Foundation\\Application), Array, Array, NULL)\n#6 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Bus\\Dispatcher.php(128): Illuminate\\Container\\Container->call(Array)\n#7 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(128): Illuminate\\Bus\\Dispatcher->Illuminate\\Bus\\{closure}(Object(App\\Jobs\\QueueCustomInvoiceNotification))\n#8 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(103): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(App\\Jobs\\QueueCustomInvoiceNotification))\n#9 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Bus\\Dispatcher.php(132): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#10 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\CallQueuedHandler.php(118): Illuminate\\Bus\\Dispatcher->dispatchNow(Object(App\\Jobs\\QueueCustomInvoiceNotification), false)\n#11 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(128): Illuminate\\Queue\\CallQueuedHandler->Illuminate\\Queue\\{closure}(Object(App\\Jobs\\QueueCustomInvoiceNotification))\n#12 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(103): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(App\\Jobs\\QueueCustomInvoiceNotification))\n#13 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\CallQueuedHandler.php(120): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#14 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\CallQueuedHandler.php(70): Illuminate\\Queue\\CallQueuedHandler->dispatchThroughMiddleware(Object(Illuminate\\Queue\\Jobs\\DatabaseJob), Object(App\\Jobs\\QueueCustomInvoiceNotification))\n#15 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Jobs\\Job.php(98): Illuminate\\Queue\\CallQueuedHandler->call(Object(Illuminate\\Queue\\Jobs\\DatabaseJob), Array)\n#16 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Worker.php(406): Illuminate\\Queue\\Jobs\\Job->fire()\n#17 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Worker.php(356): Illuminate\\Queue\\Worker->process(\'database\', Object(Illuminate\\Queue\\Jobs\\DatabaseJob), Object(Illuminate\\Queue\\WorkerOptions))\n#18 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Worker.php(158): Illuminate\\Queue\\Worker->runJob(Object(Illuminate\\Queue\\Jobs\\DatabaseJob), \'database\', Object(Illuminate\\Queue\\WorkerOptions))\n#19 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Console\\WorkCommand.php(116): Illuminate\\Queue\\Worker->daemon(\'database\', \'default\', Object(Illuminate\\Queue\\WorkerOptions))\n#20 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Console\\WorkCommand.php(100): Illuminate\\Queue\\Console\\WorkCommand->runWorker(\'database\', \'default\')\n#21 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(36): Illuminate\\Queue\\Console\\WorkCommand->handle()\n#22 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\Util.php(40): Illuminate\\Container\\BoundMethod::Illuminate\\Container\\{closure}()\n#23 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(93): Illuminate\\Container\\Util::unwrapIfClosure(Object(Closure))\n#24 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(37): Illuminate\\Container\\BoundMethod::callBoundMethod(Object(Illuminate\\Foundation\\Application), Array, Object(Closure))\n#25 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\Container.php(610): Illuminate\\Container\\BoundMethod::call(Object(Illuminate\\Foundation\\Application), Array, Array, NULL)\n#26 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Console\\Command.php(136): Illuminate\\Container\\Container->call(Array)\n#27 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\symfony\\console\\Command\\Command.php(256): Illuminate\\Console\\Command->execute(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Illuminate\\Console\\OutputStyle))\n#28 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Console\\Command.php(121): Symfony\\Component\\Console\\Command\\Command->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Illuminate\\Console\\OutputStyle))\n#29 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\symfony\\console\\Application.php(971): Illuminate\\Console\\Command->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#30 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\symfony\\console\\Application.php(290): Symfony\\Component\\Console\\Application->doRunCommand(Object(Illuminate\\Queue\\Console\\WorkCommand), Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#31 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\symfony\\console\\Application.php(166): Symfony\\Component\\Console\\Application->doRun(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#32 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Console\\Application.php(93): Symfony\\Component\\Console\\Application->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#33 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Console\\Kernel.php(129): Illuminate\\Console\\Application->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#34 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\artisan(37): Illuminate\\Foundation\\Console\\Kernel->handle(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#35 {main}','2021-03-10 11:38:08'),(9,'19683c3f-6d22-4b5b-9d29-3b14e0fbe1a3','database','default','{\"uuid\":\"19683c3f-6d22-4b5b-9d29-3b14e0fbe1a3\",\"displayName\":\"App\\\\Jobs\\\\QueueCustomInvoiceNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"App\\\\Jobs\\\\QueueCustomInvoiceNotification\",\"command\":\"O:39:\\\"App\\\\Jobs\\\\QueueCustomInvoiceNotification\\\":15:{s:12:\\\"customerName\\\";s:4:\\\"Gene\\\";s:13:\\\"customerEmail\\\";s:24:\\\"genephillip222@gmail.com\\\";s:9:\\\"invoiceId\\\";i:30;s:11:\\\"paymentDate\\\";s:19:\\\"2021-04-09 19:39:42\\\";s:8:\\\"fileName\\\";s:36:\\\"invoice-2021-03-10-1615405182-30.pdf\\\";s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";O:25:\\\"Illuminate\\\\Support\\\\Carbon\\\":3:{s:4:\\\"date\\\";s:26:\\\"2021-03-10 19:39:54.377361\\\";s:13:\\\"timezone_type\\\";i:3;s:8:\\\"timezone\\\";s:3:\\\"UTC\\\";}s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}\"}}','ErrorException: Undefined property: App\\Jobs\\QueueCustomInvoiceNotification::$email in C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\app\\Jobs\\QueueCustomInvoiceNotification.php:46\nStack trace:\n#0 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\app\\Jobs\\QueueCustomInvoiceNotification.php(46): Illuminate\\Foundation\\Bootstrap\\HandleExceptions->handleError(2, \'Undefined prope...\', \'C:\\\\xampp\\\\htdocs...\', 46)\n#1 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(36): App\\Jobs\\QueueCustomInvoiceNotification->handle()\n#2 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\Util.php(40): Illuminate\\Container\\BoundMethod::Illuminate\\Container\\{closure}()\n#3 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(93): Illuminate\\Container\\Util::unwrapIfClosure(Object(Closure))\n#4 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(37): Illuminate\\Container\\BoundMethod::callBoundMethod(Object(Illuminate\\Foundation\\Application), Array, Object(Closure))\n#5 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\Container.php(610): Illuminate\\Container\\BoundMethod::call(Object(Illuminate\\Foundation\\Application), Array, Array, NULL)\n#6 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Bus\\Dispatcher.php(128): Illuminate\\Container\\Container->call(Array)\n#7 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(128): Illuminate\\Bus\\Dispatcher->Illuminate\\Bus\\{closure}(Object(App\\Jobs\\QueueCustomInvoiceNotification))\n#8 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(103): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(App\\Jobs\\QueueCustomInvoiceNotification))\n#9 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Bus\\Dispatcher.php(132): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#10 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\CallQueuedHandler.php(118): Illuminate\\Bus\\Dispatcher->dispatchNow(Object(App\\Jobs\\QueueCustomInvoiceNotification), false)\n#11 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(128): Illuminate\\Queue\\CallQueuedHandler->Illuminate\\Queue\\{closure}(Object(App\\Jobs\\QueueCustomInvoiceNotification))\n#12 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(103): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(App\\Jobs\\QueueCustomInvoiceNotification))\n#13 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\CallQueuedHandler.php(120): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#14 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\CallQueuedHandler.php(70): Illuminate\\Queue\\CallQueuedHandler->dispatchThroughMiddleware(Object(Illuminate\\Queue\\Jobs\\DatabaseJob), Object(App\\Jobs\\QueueCustomInvoiceNotification))\n#15 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Jobs\\Job.php(98): Illuminate\\Queue\\CallQueuedHandler->call(Object(Illuminate\\Queue\\Jobs\\DatabaseJob), Array)\n#16 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Worker.php(406): Illuminate\\Queue\\Jobs\\Job->fire()\n#17 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Worker.php(356): Illuminate\\Queue\\Worker->process(\'database\', Object(Illuminate\\Queue\\Jobs\\DatabaseJob), Object(Illuminate\\Queue\\WorkerOptions))\n#18 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Worker.php(158): Illuminate\\Queue\\Worker->runJob(Object(Illuminate\\Queue\\Jobs\\DatabaseJob), \'database\', Object(Illuminate\\Queue\\WorkerOptions))\n#19 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Console\\WorkCommand.php(116): Illuminate\\Queue\\Worker->daemon(\'database\', \'default\', Object(Illuminate\\Queue\\WorkerOptions))\n#20 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Console\\WorkCommand.php(100): Illuminate\\Queue\\Console\\WorkCommand->runWorker(\'database\', \'default\')\n#21 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(36): Illuminate\\Queue\\Console\\WorkCommand->handle()\n#22 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\Util.php(40): Illuminate\\Container\\BoundMethod::Illuminate\\Container\\{closure}()\n#23 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(93): Illuminate\\Container\\Util::unwrapIfClosure(Object(Closure))\n#24 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(37): Illuminate\\Container\\BoundMethod::callBoundMethod(Object(Illuminate\\Foundation\\Application), Array, Object(Closure))\n#25 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\Container.php(610): Illuminate\\Container\\BoundMethod::call(Object(Illuminate\\Foundation\\Application), Array, Array, NULL)\n#26 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Console\\Command.php(136): Illuminate\\Container\\Container->call(Array)\n#27 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\symfony\\console\\Command\\Command.php(256): Illuminate\\Console\\Command->execute(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Illuminate\\Console\\OutputStyle))\n#28 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Console\\Command.php(121): Symfony\\Component\\Console\\Command\\Command->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Illuminate\\Console\\OutputStyle))\n#29 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\symfony\\console\\Application.php(971): Illuminate\\Console\\Command->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#30 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\symfony\\console\\Application.php(290): Symfony\\Component\\Console\\Application->doRunCommand(Object(Illuminate\\Queue\\Console\\WorkCommand), Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#31 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\symfony\\console\\Application.php(166): Symfony\\Component\\Console\\Application->doRun(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#32 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Console\\Application.php(93): Symfony\\Component\\Console\\Application->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#33 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Console\\Kernel.php(129): Illuminate\\Console\\Application->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#34 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\artisan(37): Illuminate\\Foundation\\Console\\Kernel->handle(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#35 {main}','2021-03-10 11:39:55'),(10,'21b94bf8-3e46-4c1e-82cb-11e883faad00','database','default','{\"uuid\":\"21b94bf8-3e46-4c1e-82cb-11e883faad00\",\"displayName\":\"App\\\\Jobs\\\\QueueCustomInvoiceNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"App\\\\Jobs\\\\QueueCustomInvoiceNotification\",\"command\":\"O:39:\\\"App\\\\Jobs\\\\QueueCustomInvoiceNotification\\\":15:{s:12:\\\"customerName\\\";s:4:\\\"Gene\\\";s:13:\\\"customerEmail\\\";s:24:\\\"genephillip222@gmail.com\\\";s:9:\\\"invoiceId\\\";i:31;s:11:\\\"paymentDate\\\";s:19:\\\"2021-04-09 19:56:10\\\";s:8:\\\"fileName\\\";s:36:\\\"invoice-2021-03-10-1615406170-31.pdf\\\";s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";O:25:\\\"Illuminate\\\\Support\\\\Carbon\\\":3:{s:4:\\\"date\\\";s:26:\\\"2021-03-10 19:56:22.728479\\\";s:13:\\\"timezone_type\\\";i:3;s:8:\\\"timezone\\\";s:3:\\\"UTC\\\";}s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}\"}}','ErrorException: Undefined property: App\\Jobs\\QueueCustomInvoiceNotification::$email in C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\app\\Jobs\\QueueCustomInvoiceNotification.php:46\nStack trace:\n#0 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\app\\Jobs\\QueueCustomInvoiceNotification.php(46): Illuminate\\Foundation\\Bootstrap\\HandleExceptions->handleError(2, \'Undefined prope...\', \'C:\\\\xampp\\\\htdocs...\', 46)\n#1 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(36): App\\Jobs\\QueueCustomInvoiceNotification->handle()\n#2 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\Util.php(40): Illuminate\\Container\\BoundMethod::Illuminate\\Container\\{closure}()\n#3 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(93): Illuminate\\Container\\Util::unwrapIfClosure(Object(Closure))\n#4 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(37): Illuminate\\Container\\BoundMethod::callBoundMethod(Object(Illuminate\\Foundation\\Application), Array, Object(Closure))\n#5 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\Container.php(610): Illuminate\\Container\\BoundMethod::call(Object(Illuminate\\Foundation\\Application), Array, Array, NULL)\n#6 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Bus\\Dispatcher.php(128): Illuminate\\Container\\Container->call(Array)\n#7 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(128): Illuminate\\Bus\\Dispatcher->Illuminate\\Bus\\{closure}(Object(App\\Jobs\\QueueCustomInvoiceNotification))\n#8 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(103): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(App\\Jobs\\QueueCustomInvoiceNotification))\n#9 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Bus\\Dispatcher.php(132): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#10 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\CallQueuedHandler.php(118): Illuminate\\Bus\\Dispatcher->dispatchNow(Object(App\\Jobs\\QueueCustomInvoiceNotification), false)\n#11 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(128): Illuminate\\Queue\\CallQueuedHandler->Illuminate\\Queue\\{closure}(Object(App\\Jobs\\QueueCustomInvoiceNotification))\n#12 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(103): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(App\\Jobs\\QueueCustomInvoiceNotification))\n#13 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\CallQueuedHandler.php(120): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#14 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\CallQueuedHandler.php(70): Illuminate\\Queue\\CallQueuedHandler->dispatchThroughMiddleware(Object(Illuminate\\Queue\\Jobs\\DatabaseJob), Object(App\\Jobs\\QueueCustomInvoiceNotification))\n#15 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Jobs\\Job.php(98): Illuminate\\Queue\\CallQueuedHandler->call(Object(Illuminate\\Queue\\Jobs\\DatabaseJob), Array)\n#16 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Worker.php(406): Illuminate\\Queue\\Jobs\\Job->fire()\n#17 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Worker.php(356): Illuminate\\Queue\\Worker->process(\'database\', Object(Illuminate\\Queue\\Jobs\\DatabaseJob), Object(Illuminate\\Queue\\WorkerOptions))\n#18 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Worker.php(158): Illuminate\\Queue\\Worker->runJob(Object(Illuminate\\Queue\\Jobs\\DatabaseJob), \'database\', Object(Illuminate\\Queue\\WorkerOptions))\n#19 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Console\\WorkCommand.php(116): Illuminate\\Queue\\Worker->daemon(\'database\', \'default\', Object(Illuminate\\Queue\\WorkerOptions))\n#20 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Console\\WorkCommand.php(100): Illuminate\\Queue\\Console\\WorkCommand->runWorker(\'database\', \'default\')\n#21 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(36): Illuminate\\Queue\\Console\\WorkCommand->handle()\n#22 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\Util.php(40): Illuminate\\Container\\BoundMethod::Illuminate\\Container\\{closure}()\n#23 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(93): Illuminate\\Container\\Util::unwrapIfClosure(Object(Closure))\n#24 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(37): Illuminate\\Container\\BoundMethod::callBoundMethod(Object(Illuminate\\Foundation\\Application), Array, Object(Closure))\n#25 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\Container.php(610): Illuminate\\Container\\BoundMethod::call(Object(Illuminate\\Foundation\\Application), Array, Array, NULL)\n#26 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Console\\Command.php(136): Illuminate\\Container\\Container->call(Array)\n#27 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\symfony\\console\\Command\\Command.php(256): Illuminate\\Console\\Command->execute(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Illuminate\\Console\\OutputStyle))\n#28 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Console\\Command.php(121): Symfony\\Component\\Console\\Command\\Command->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Illuminate\\Console\\OutputStyle))\n#29 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\symfony\\console\\Application.php(971): Illuminate\\Console\\Command->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#30 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\symfony\\console\\Application.php(290): Symfony\\Component\\Console\\Application->doRunCommand(Object(Illuminate\\Queue\\Console\\WorkCommand), Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#31 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\symfony\\console\\Application.php(166): Symfony\\Component\\Console\\Application->doRun(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#32 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Console\\Application.php(93): Symfony\\Component\\Console\\Application->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#33 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Console\\Kernel.php(129): Illuminate\\Console\\Application->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#34 C:\\xampp\\htdocs\\GeneRepo\\Laravel-Projects\\pos_test\\gpa-laravel-pos-inventory\\artisan(37): Illuminate\\Foundation\\Console\\Kernel->handle(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#35 {main}','2021-03-10 11:56:22');
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `invoice_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoice_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `invoice_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `quantity` int(10) unsigned NOT NULL DEFAULT 1,
  `price` double(20,2) unsigned NOT NULL DEFAULT 0.00,
  `unit_of_measurement` char(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'each',
  `sub_total` double(20,2) unsigned NOT NULL DEFAULT 0.00,
  `discount` double(20,2) unsigned NOT NULL DEFAULT 0.00,
  `tax` double(20,2) unsigned NOT NULL DEFAULT 0.00,
  `total` double(20,2) unsigned NOT NULL DEFAULT 0.00,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `invoice_details_invoice_id_foreign` (`invoice_id`),
  CONSTRAINT `invoice_details_invoice_id_foreign` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `invoice_details` WRITE;
/*!40000 ALTER TABLE `invoice_details` DISABLE KEYS */;
INSERT INTO `invoice_details` VALUES (15,14,1,1,1200.50,'each',1200.50,0.00,144.06,1344.56,'2021-03-10 10:49:51',NULL),(26,20,1,1,1200.50,'each',1200.50,0.00,144.06,1344.56,'2021-03-10 10:57:24',NULL),(27,20,3,1,10.00,'each',10.00,0.00,1.20,11.20,'2021-03-10 10:57:24',NULL),(28,21,1,1,1200.50,'each',1200.50,0.00,144.06,1344.56,'2021-03-10 11:09:50',NULL),(29,22,1,1,1200.50,'each',1200.50,0.00,144.06,1344.56,'2021-03-10 11:12:56',NULL),(30,22,3,1,10.00,'each',10.00,0.00,1.20,11.20,'2021-03-10 11:12:56',NULL),(31,23,1,1,1200.50,'each',1200.50,0.00,144.06,1344.56,'2021-03-10 11:14:33',NULL),(32,23,3,1,10.00,'each',10.00,0.00,1.20,11.20,'2021-03-10 11:14:33',NULL),(33,24,1,1,1200.50,'each',1200.50,0.00,144.06,1344.56,'2021-03-10 11:21:31',NULL),(34,24,3,1,10.00,'each',10.00,0.00,1.20,11.20,'2021-03-10 11:21:31',NULL),(35,25,1,1,1200.50,'each',1200.50,0.00,144.06,1344.56,'2021-03-10 11:24:11',NULL),(36,25,3,1,10.00,'each',10.00,0.00,1.20,11.20,'2021-03-10 11:24:11',NULL),(37,27,1,1,1200.50,'each',1200.50,0.00,144.06,1344.56,'2021-03-10 11:32:19',NULL),(38,28,1,1,1200.50,'each',1200.50,0.00,144.06,1344.56,'2021-03-10 11:33:45',NULL),(39,29,1,1,1200.50,'each',1200.50,0.00,144.06,1344.56,'2021-03-10 11:37:53',NULL),(40,30,1,1,1200.50,'each',1200.50,0.00,144.06,1344.56,'2021-03-10 11:39:42',NULL),(41,31,1,1,1200.50,'each',1200.50,0.00,144.06,1344.56,'2021-03-10 11:56:10',NULL);
/*!40000 ALTER TABLE `invoice_details` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoices` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `cashier` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_id` bigint(20) unsigned NOT NULL,
  `status` char(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Payment in process',
  `payment_date` timestamp NULL DEFAULT NULL,
  `paid_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `invoices_customer_id_foreign` (`customer_id`),
  CONSTRAINT `invoices_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `invoices` WRITE;
/*!40000 ALTER TABLE `invoices` DISABLE KEYS */;
INSERT INTO `invoices` VALUES (14,'admin',1,'Payment in process','2021-04-09 10:49:51',NULL,'2021-03-10 10:49:51','2021-03-10 10:49:51'),(20,'admin',1,'Payment in process','2021-04-09 10:57:24',NULL,'2021-03-10 10:57:24','2021-03-10 10:57:24'),(21,'admin',3,'Payment in process','2021-04-09 11:09:50',NULL,'2021-03-10 11:09:50','2021-03-10 11:09:50'),(22,'admin',1,'Payment in process','2021-04-09 11:12:56',NULL,'2021-03-10 11:12:56','2021-03-10 11:12:56'),(23,'admin',1,'Payment in process','2021-04-09 11:14:33',NULL,'2021-03-10 11:14:33','2021-03-10 11:14:33'),(24,'admin',1,'Payment in process','2021-04-09 11:21:31',NULL,'2021-03-10 11:21:31','2021-03-10 11:21:31'),(25,'admin',1,'Payment in process','2021-04-09 11:24:11',NULL,'2021-03-10 11:24:11','2021-03-10 11:24:11'),(27,'admin',1,'Payment in process','2021-04-09 11:32:19',NULL,'2021-03-10 11:32:19','2021-03-10 11:32:19'),(28,'admin',1,'Payment in process','2021-04-09 11:33:45',NULL,'2021-03-10 11:33:45','2021-03-10 11:33:45'),(29,'admin',1,'Payment in process','2021-04-09 11:37:53',NULL,'2021-03-10 11:37:53','2021-03-10 11:37:53'),(30,'admin',1,'Payment in process','2021-04-09 11:39:42',NULL,'2021-03-10 11:39:42','2021-03-10 11:39:42'),(31,'admin',1,'Payment in process','2021-04-09 11:56:10',NULL,'2021-03-10 11:56:10','2021-03-10 11:56:10');
/*!40000 ALTER TABLE `invoices` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_100000_create_password_resets_table',1),(2,'2016_06_01_000001_create_oauth_auth_codes_table',1),(3,'2016_06_01_000002_create_oauth_access_tokens_table',1),(4,'2016_06_01_000003_create_oauth_refresh_tokens_table',1),(5,'2016_06_01_000004_create_oauth_clients_table',1),(6,'2016_06_01_000005_create_oauth_personal_access_clients_table',1),(7,'2019_08_19_000000_create_failed_jobs_table',1),(8,'2021_01_08_163932_create_permission_tables',1),(9,'2021_01_14_161155_create_products_table',1),(10,'2021_01_14_165315_create_categories_table',1),(11,'2021_01_14_182050_create_users_table',1),(12,'2021_01_16_025901_create_suppliers_table',1),(13,'2021_01_23_153847_create_purchase_order_table',1),(14,'2021_01_24_133445_create_customers_table',1),(15,'2021_01_25_122814_create_stocks_table',1),(16,'2021_01_28_175954_create_bad_orders_table',1),(17,'2021_02_01_141530_create_invoices_table',1),(18,'2021_02_01_162927_create_discounts_table',1),(19,'2021_02_02_204858_create_pos_table',1),(20,'2021_02_03_131253_create_sales_returns_table',1),(21,'2021_02_03_131409_create_pos_payments_table',1),(22,'2021_02_04_203324_create_notifications_table',1),(23,'2021_02_06_171138_create_jobs_table',1),(24,'2021_02_12_134142_create_stock_adjustments_table',1),(25,'2021_02_15_154210_create_access_rights_table',1),(26,'2021_02_15_183259_create_received_stocks_table',1),(27,'2021_02_16_200729_create_employees_table',1),(28,'2021_03_03_154147_create_system_permission_table',1),(29,'2021_03_04_184132_create_sales_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
INSERT INTO `model_has_permissions` VALUES (1,'App\\Models\\User',1),(2,'App\\Models\\User',1),(3,'App\\Models\\User',1),(4,'App\\Models\\User',1),(5,'App\\Models\\User',1),(6,'App\\Models\\User',1),(7,'App\\Models\\User',1),(8,'App\\Models\\User',1),(9,'App\\Models\\User',1),(10,'App\\Models\\User',1),(11,'App\\Models\\User',1),(12,'App\\Models\\User',1),(13,'App\\Models\\User',1),(14,'App\\Models\\User',1),(15,'App\\Models\\User',1),(16,'App\\Models\\User',1),(17,'App\\Models\\User',1),(18,'App\\Models\\User',1),(19,'App\\Models\\User',1),(20,'App\\Models\\User',1),(21,'App\\Models\\User',1),(22,'App\\Models\\User',1);
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES (1,'App\\Models\\User',1),(3,'App\\Models\\User',2);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint(20) unsigned NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES ('1c7286ba-cdb5-48e7-a275-034fc6db5b26','App\\Notifications\\InvoiceNotification','App\\Models\\Customer',3,'[]',NULL,'2021-03-10 11:10:09','2021-03-10 11:10:09'),('4e4aa9a9-f43e-4e21-b5f6-1fc63e051fdb','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'[]',NULL,'2021-03-10 11:38:15','2021-03-10 11:38:15'),('5aa92b04-6e76-4b85-9461-2f20f045a0d6','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'[]',NULL,'2021-03-10 11:56:32','2021-03-10 11:56:32'),('62780e4f-e236-4697-8ed4-8065e1a5f605','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'[]',NULL,'2021-03-10 11:29:59','2021-03-10 11:29:59'),('76b77768-2f42-4c74-b30f-a1076be45c05','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'[]',NULL,'2021-03-10 11:32:41','2021-03-10 11:32:41'),('8aebaf92-de52-46b6-85d8-b33c32b6ad90','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'[]',NULL,'2021-03-10 11:40:02','2021-03-10 11:40:02'),('a2f86565-5b8f-47bd-aa78-514f7a45d812','App\\Notifications\\InvoiceNotification','App\\Models\\Customer',1,'[]',NULL,'2021-03-10 10:57:41','2021-03-10 10:57:41'),('bc83b204-c7e8-4ac6-8a9d-c9316df21476','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'[]',NULL,'2021-03-10 11:34:10','2021-03-10 11:34:10'),('beb01b4a-eef0-40a0-98ba-704577a857c8','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'[]',NULL,'2021-03-10 08:08:28','2021-03-10 08:08:28'),('c847e37b-edca-4dc3-b147-2f6ae8a92bbb','App\\Notifications\\PurchaseOrderNotification','App\\Models\\Supplier',1,'[]',NULL,'2021-03-10 08:00:35','2021-03-10 08:00:35');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `oauth_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_access_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `client_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_access_tokens_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `oauth_access_tokens` WRITE;
/*!40000 ALTER TABLE `oauth_access_tokens` DISABLE KEYS */;
INSERT INTO `oauth_access_tokens` VALUES ('15c70319051715cddc0455118c7e8f45556c947fb7fc03a372964b65a2c431d9fa20d8aae8ed3b05',1,1,'Personal Access Token','[]',0,'2021-03-09 09:55:41','2021-03-09 09:55:41','2022-03-09 17:55:41'),('24ccfea67fab665862d39a3068ac51d33be65ec1b79031f5a1374e2ac7ad56cdb1066e93ea2de0d7',1,1,'Personal Access Token','[]',0,'2021-03-09 12:30:38','2021-03-09 12:30:38','2022-03-09 20:30:38'),('5e0a84f158d6f85dc79396529236004f636b1ace49bba5209ad402bcbe7b91a8a182183c3d5941b1',1,1,'Personal Access Token','[]',0,'2021-03-10 07:14:23','2021-03-10 07:14:23','2022-03-10 15:14:23'),('9fa94190d20d15965c7a1e360706b1fd66108073bee9dce9cb480125e6bdb1896cacb74221703136',1,1,'Personal Access Token','[]',0,'2021-03-09 12:23:48','2021-03-09 12:23:48','2022-03-09 20:23:48'),('a33c0e6b9f81dacfb702792986d690c4277e6221eb0a08a4ce00d734026874f6839e75f7a38ef72f',2,1,'Personal Access Token','[]',0,'2021-03-09 12:32:06','2021-03-09 12:32:06','2022-03-09 20:32:06');
/*!40000 ALTER TABLE `oauth_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `oauth_auth_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_auth_codes` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `client_id` bigint(20) unsigned NOT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_auth_codes_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `oauth_auth_codes` WRITE;
/*!40000 ALTER TABLE `oauth_auth_codes` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_auth_codes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `oauth_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_clients` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `redirect` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_clients_user_id_index` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `oauth_clients` WRITE;
/*!40000 ALTER TABLE `oauth_clients` DISABLE KEYS */;
INSERT INTO `oauth_clients` VALUES (1,NULL,'POS - In Inc. GPA Personal Access Client','Z9BCCOVvXikZPHgL6atOzi2HqNu3nr944xkt9919',NULL,'http://localhost',1,0,0,'2021-03-09 09:53:53','2021-03-09 09:53:53'),(2,NULL,'POS - In Inc. GPA Password Grant Client','m1ql9Xx3hoUsfruW7Q1dXYPXHyhLkKZusDIBiASh','users','http://localhost',0,1,0,'2021-03-09 09:53:54','2021-03-09 09:53:54');
/*!40000 ALTER TABLE `oauth_clients` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `oauth_personal_access_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_personal_access_clients` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `oauth_personal_access_clients` WRITE;
/*!40000 ALTER TABLE `oauth_personal_access_clients` DISABLE KEYS */;
INSERT INTO `oauth_personal_access_clients` VALUES (1,1,'2021-03-09 09:53:53','2021-03-09 09:53:53');
/*!40000 ALTER TABLE `oauth_personal_access_clients` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `oauth_refresh_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_refresh_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `oauth_refresh_tokens` WRITE;
/*!40000 ALTER TABLE `oauth_refresh_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_refresh_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'View Dashboard','api','2021-03-09 09:42:54',NULL),(2,'Manage POS','api','2021-03-09 09:42:54',NULL),(3,'View Reports','api','2021-03-09 09:42:54',NULL),(4,'Manage Products','api','2021-03-09 09:42:54',NULL),(5,'Import Products','api','2021-03-09 09:42:54',NULL),(6,'Manage Categories','api','2021-03-09 09:42:54',NULL),(7,'Manage Discounts','api','2021-03-09 09:42:54',NULL),(8,'Manage System Permission','api','2021-03-09 09:42:54',NULL),(9,'Manage Purchase Orders','api','2021-03-09 09:42:54',NULL),(10,'Manage Bad Orders','api','2021-03-09 09:42:54',NULL),(11,'Manage Suppliers','api','2021-03-09 09:42:54',NULL),(12,'Manage Stock Adjustments','api','2021-03-09 09:42:54',NULL),(13,'Manage Customers','api','2021-03-09 09:42:54',NULL),(14,'Manage Access Rights','api','2021-03-09 09:42:54',NULL),(15,'Manage Employees','api','2021-03-09 09:42:54',NULL),(16,'View Transactions','api','2021-03-09 09:42:54',NULL),(17,'View All Receipts','api','2021-03-09 09:42:54',NULL),(18,'Manage Invoices','api','2021-03-09 09:42:54',NULL),(19,'Manage Settings','api','2021-03-09 09:42:54',NULL),(20,'Manage Sales Returns','api','2021-03-09 09:42:54',NULL),(21,'Manage Account','api','2021-03-09 09:42:54',NULL),(22,'View Receipts','api','2021-03-09 09:42:54',NULL);
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `cashier` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_id` bigint(20) unsigned DEFAULT NULL,
  `status` char(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pos_customer_id_foreign` (`customer_id`),
  CONSTRAINT `pos_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pos` WRITE;
/*!40000 ALTER TABLE `pos` DISABLE KEYS */;
INSERT INTO `pos` VALUES (1,'admin',1,'Credit','2021-03-10 06:33:15','2021-03-10 06:35:19'),(2,'admin',1,'Cash','2021-03-10 06:39:31','2021-03-10 07:55:05'),(3,'admin',3,'Invoice','2021-03-10 07:14:45','2021-03-10 07:57:14'),(4,'admin',1,'Credit','2021-03-10 08:01:33','2021-03-10 08:08:08'),(5,'admin',1,'Invoice','2021-03-10 10:12:03','2021-03-10 10:12:24'),(6,'admin',1,'Invoice','2021-03-10 10:13:57','2021-03-10 10:14:13'),(7,'admin',1,'Invoice','2021-03-10 10:18:17','2021-03-10 10:49:51'),(8,'admin',1,'Invoice','2021-03-10 10:24:38','2021-03-10 10:57:30'),(9,'admin',3,'Invoice','2021-03-10 10:30:47','2021-03-10 10:31:32'),(10,'admin',3,'Invoice','2021-03-10 10:32:26','2021-03-10 10:32:36'),(11,'admin',3,'Invoice','2021-03-10 10:33:09','2021-03-10 10:33:22'),(12,'admin',3,'Invoice','2021-03-10 11:09:23','2021-03-10 11:09:53'),(13,'admin',1,'Invoice','2021-03-10 11:12:35','2021-03-10 11:12:59'),(14,'admin',1,'Invoice','2021-03-10 11:14:13','2021-03-10 11:24:16'),(15,'admin',1,'Pending','2021-03-10 11:26:03','2021-03-10 11:56:12');
/*!40000 ALTER TABLE `pos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pos_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pos_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `pos_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `discount_id` bigint(20) unsigned DEFAULT NULL,
  `quantity` int(10) unsigned NOT NULL DEFAULT 1,
  `price` double(20,2) unsigned NOT NULL DEFAULT 0.00,
  `unit_of_measurement` char(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pcs',
  `sub_total` double(20,2) unsigned NOT NULL DEFAULT 0.00,
  `discount` double(20,2) unsigned NOT NULL DEFAULT 0.00,
  `tax` double(20,2) unsigned NOT NULL DEFAULT 0.00,
  `total` double(20,2) unsigned NOT NULL DEFAULT 0.00,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pos_details_pos_id_product_id_unique` (`pos_id`,`product_id`),
  CONSTRAINT `pos_details_pos_id_foreign` FOREIGN KEY (`pos_id`) REFERENCES `pos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pos_details` WRITE;
/*!40000 ALTER TABLE `pos_details` DISABLE KEYS */;
INSERT INTO `pos_details` VALUES (1,1,1,1,5,1200.50,'each',6002.50,600.25,720.30,6122.55,'2021-03-10 06:33:15','2021-03-10 06:34:02'),(4,2,1,NULL,2,1200.50,'each',2401.00,0.00,288.12,2689.12,'2021-03-10 06:39:31','2021-03-10 07:14:39'),(6,3,1,1,3,1200.50,'each',3601.50,360.15,432.18,3673.53,'2021-03-10 07:14:45','2021-03-10 07:15:04'),(9,4,1,NULL,111,1200.50,'each',133255.50,0.00,15990.66,149246.16,'2021-03-10 08:01:33','2021-03-10 08:01:57'),(10,5,3,NULL,1,10.00,'each',10.00,0.00,1.20,11.20,'2021-03-10 10:12:03','2021-03-10 10:12:03'),(11,5,1,NULL,1,1200.50,'each',1200.50,0.00,144.06,1344.56,'2021-03-10 10:12:03',NULL),(12,6,3,NULL,1,10.00,'each',10.00,0.00,1.20,11.20,'2021-03-10 10:13:57','2021-03-10 10:13:57'),(13,6,1,NULL,1,1200.50,'each',1200.50,0.00,144.06,1344.56,'2021-03-10 10:13:58',NULL),(14,7,1,NULL,1,1200.50,'each',1200.50,0.00,144.06,1344.56,'2021-03-10 10:18:17','2021-03-10 10:18:17'),(15,8,1,NULL,1,1200.50,'each',1200.50,0.00,144.06,1344.56,'2021-03-10 10:24:38','2021-03-10 10:24:38'),(16,8,3,NULL,1,10.00,'each',10.00,0.00,1.20,11.20,'2021-03-10 10:24:40',NULL),(17,9,1,NULL,1,1200.50,'each',1200.50,0.00,144.06,1344.56,'2021-03-10 10:30:47','2021-03-10 10:30:47'),(18,10,1,NULL,1,1200.50,'each',1200.50,0.00,144.06,1344.56,'2021-03-10 10:32:26','2021-03-10 10:32:26'),(19,11,1,NULL,1,1200.50,'each',1200.50,0.00,144.06,1344.56,'2021-03-10 10:33:09','2021-03-10 10:33:09'),(20,12,1,NULL,1,1200.50,'each',1200.50,0.00,144.06,1344.56,'2021-03-10 11:09:23','2021-03-10 11:09:23'),(21,13,1,NULL,1,1200.50,'each',1200.50,0.00,144.06,1344.56,'2021-03-10 11:12:35','2021-03-10 11:12:35'),(22,13,3,NULL,1,10.00,'each',10.00,0.00,1.20,11.20,'2021-03-10 11:12:36',NULL),(23,14,1,NULL,1,1200.50,'each',1200.50,0.00,144.06,1344.56,'2021-03-10 11:14:13','2021-03-10 11:14:13'),(24,14,3,NULL,1,10.00,'each',10.00,0.00,1.20,11.20,'2021-03-10 11:14:14',NULL),(25,15,1,NULL,1,1200.50,'each',1200.50,0.00,144.06,1344.56,'2021-03-10 11:26:03','2021-03-10 11:26:03');
/*!40000 ALTER TABLE `pos_details` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pos_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pos_payments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `pos_id` bigint(20) unsigned DEFAULT NULL,
  `cashier` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_method` char(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'cash',
  `no_of_items_bought` int(10) unsigned NOT NULL DEFAULT 0,
  `sub_total` double(20,2) unsigned NOT NULL DEFAULT 0.00,
  `discount` double(20,2) unsigned NOT NULL DEFAULT 0.00,
  `tax` double(20,2) unsigned NOT NULL DEFAULT 0.00,
  `total` double(20,2) unsigned NOT NULL,
  `cash` double(20,2) unsigned NOT NULL DEFAULT 0.00,
  `change` double(20,2) unsigned NOT NULL DEFAULT 0.00,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pos_payments_pos_id_unique` (`pos_id`),
  CONSTRAINT `pos_payments_pos_id_foreign` FOREIGN KEY (`pos_id`) REFERENCES `pos` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pos_payments` WRITE;
/*!40000 ALTER TABLE `pos_payments` DISABLE KEYS */;
INSERT INTO `pos_payments` VALUES (1,1,'admin','credit',5,6002.50,600.25,720.30,6122.55,6122.55,0.00,'2021-03-10 06:35:18','2021-03-10 06:35:18'),(2,2,'admin','cash',2,2401.00,0.00,288.12,2689.12,3000.00,310.88,'2021-03-10 07:55:05','2021-03-10 07:55:05'),(3,4,'admin','credit',111,133255.50,0.00,15990.66,149246.16,149246.16,0.00,'2021-03-10 08:08:05','2021-03-10 08:08:05');
/*!40000 ALTER TABLE `pos_payments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `sku` char(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `barcode` char(13) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'http://127.0.0.1:8000/storage/images/Products/product_default_img_1614450024.svg',
  `category` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sold_by` char(13) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` double(10,2) unsigned NOT NULL,
  `cost` double(10,2) unsigned NOT NULL,
  `is_for_sale` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `products_sku_barcode_unique` (`sku`,`barcode`),
  UNIQUE KEY `products_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'currysku1234','currybarcode','Underarmour Curry','http://127.0.0.1:8000/storage/images/Products/download_1615316380.jpg','1','each',1200.50,1000.00,1,'2021-03-09 11:00:29','2021-03-09 11:23:14'),(2,'111111111112','111111111112','Trinx','no_image.svg','3','each',120.00,100.00,0,'2021-03-10 08:45:14','2021-03-10 08:45:14'),(3,'111111111A2','21111111123','Nike','no_image.svg','1','each',10.00,5.00,1,'2021-03-10 08:48:46','2021-03-10 08:48:46'),(4,'11111131112','545454444','Foxter','http://127.0.0.1:8000/storage/images/Products/product_default_img_1614450024.svg','1','each',10.00,5.00,1,'2021-03-10 08:52:12','2021-03-10 08:52:12'),(5,'11111114112','123233323','Asic','http://127.0.0.1:8000/storage/images/Products/product_default_img_1614450024.svg','1','each',10.00,5.00,1,'2021-03-10 09:00:43','2021-03-10 09:01:12');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `purchase_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_order` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ordered_by` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `supplier_id` bigint(20) unsigned NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Pending',
  `total_received_quantity` int(10) unsigned NOT NULL DEFAULT 0,
  `total_ordered_quantity` int(10) unsigned NOT NULL DEFAULT 0,
  `total_remaining_ordered_quantity` int(10) unsigned NOT NULL DEFAULT 0,
  `purchase_order_date` timestamp NULL DEFAULT NULL,
  `expected_delivery_date` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `purchase_order_supplier_id_foreign` (`supplier_id`),
  CONSTRAINT `purchase_order_supplier_id_foreign` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `purchase_order` WRITE;
/*!40000 ALTER TABLE `purchase_order` DISABLE KEYS */;
INSERT INTO `purchase_order` VALUES (1,'admin',1,'Closed',21,21,0,'2021-03-09 16:00:00','2021-03-09 16:00:00','2021-03-09 13:25:23','2021-03-10 08:14:33'),(2,'admin',1,'Closed',21,21,0,'2021-03-10 16:00:00','2021-03-10 16:00:00','2021-03-10 08:32:22','2021-03-10 08:35:20'),(3,'admin',1,'Closed',1,1,0,'2021-03-10 16:00:00','2021-03-10 16:00:00','2021-03-10 08:39:27','2021-03-10 08:39:40'),(4,'admin',1,'Closed',22,22,0,'2021-03-10 16:00:00','2021-03-30 16:00:00','2021-03-10 09:02:50','2021-03-10 09:37:19'),(5,'admin',1,'Closed',13,13,0,'2021-03-10 16:00:00','2021-03-10 16:00:00','2021-03-10 09:38:11','2021-03-10 09:40:53'),(6,'admin',1,'Cancelled',0,1,0,'2021-03-10 16:00:00','2021-03-10 16:00:00','2021-03-10 09:41:55','2021-03-10 09:42:10');
/*!40000 ALTER TABLE `purchase_order` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `purchase_order_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_order_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `purchase_order_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `received_quantity` int(10) unsigned NOT NULL DEFAULT 0,
  `ordered_quantity` int(10) unsigned NOT NULL DEFAULT 1,
  `remaining_ordered_quantity` int(10) unsigned NOT NULL DEFAULT 1,
  `cancelled_quantity` int(10) unsigned NOT NULL DEFAULT 0,
  `purchase_cost` double(10,2) unsigned NOT NULL DEFAULT 0.00,
  `amount` double(10,2) unsigned NOT NULL DEFAULT 0.00,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `purchase_order_details_purchase_order_id_product_id_unique` (`purchase_order_id`,`product_id`),
  KEY `purchase_order_details_product_id_foreign` (`product_id`),
  CONSTRAINT `purchase_order_details_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `purchase_order_details` WRITE;
/*!40000 ALTER TABLE `purchase_order_details` DISABLE KEYS */;
INSERT INTO `purchase_order_details` VALUES (1,1,1,21,21,0,0,2.00,42.00,'2021-03-09 13:25:23','2021-03-10 08:14:33'),(2,2,1,21,21,0,0,20.00,420.00,'2021-03-10 08:32:22','2021-03-10 08:35:20'),(3,3,1,1,1,0,0,20.00,20.00,'2021-03-10 08:39:27','2021-03-10 08:39:40'),(6,4,3,1,1,0,0,20.00,20.00,NULL,'2021-03-10 09:37:19'),(8,4,2,1,1,0,0,20.00,20.00,NULL,'2021-03-10 09:37:19'),(10,4,1,10,10,0,0,30.00,300.00,NULL,'2021-03-10 09:37:19'),(11,4,5,10,10,0,0,30.00,300.00,NULL,'2021-03-10 09:37:19'),(14,5,4,1,1,0,0,10.00,10.00,'2021-03-10 09:38:11','2021-03-10 09:40:53'),(15,5,2,11,11,0,0,10.00,110.00,'2021-03-10 09:38:11','2021-03-10 09:40:53'),(16,5,1,1,1,0,0,10.00,10.00,NULL,'2021-03-10 09:40:53'),(18,6,4,0,1,0,1,20.00,20.00,'2021-03-10 09:41:55','2021-03-10 09:42:10');
/*!40000 ALTER TABLE `purchase_order_details` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `received_stock_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `received_stock_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `received_stock_id` bigint(20) unsigned NOT NULL,
  `purchase_order_details_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned DEFAULT NULL,
  `received_quantity` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `received_stock_details_received_stock_id_foreign` (`received_stock_id`),
  KEY `received_stock_details_purchase_order_details_id_foreign` (`purchase_order_details_id`),
  CONSTRAINT `received_stock_details_purchase_order_details_id_foreign` FOREIGN KEY (`purchase_order_details_id`) REFERENCES `purchase_order_details` (`id`) ON DELETE CASCADE,
  CONSTRAINT `received_stock_details_received_stock_id_foreign` FOREIGN KEY (`received_stock_id`) REFERENCES `received_stocks` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `received_stock_details` WRITE;
/*!40000 ALTER TABLE `received_stock_details` DISABLE KEYS */;
INSERT INTO `received_stock_details` VALUES (1,1,1,1,3,'2021-03-09 13:28:23','2021-03-09 13:28:23'),(2,2,2,1,0,'2021-03-10 08:35:20','2021-03-10 08:35:20'),(3,3,3,1,1,'2021-03-10 08:39:40','2021-03-10 08:39:40'),(6,5,6,3,1,'2021-03-10 09:33:18','2021-03-10 09:33:18'),(7,5,8,2,1,'2021-03-10 09:33:18','2021-03-10 09:33:18'),(8,6,6,3,1,'2021-03-10 09:37:19','2021-03-10 09:37:19'),(9,6,8,2,1,'2021-03-10 09:37:19','2021-03-10 09:37:19'),(10,6,10,1,10,'2021-03-10 09:37:19','2021-03-10 09:37:19'),(11,6,11,5,10,'2021-03-10 09:37:19','2021-03-10 09:37:19'),(12,7,14,4,1,'2021-03-10 09:38:39','2021-03-10 09:38:39'),(13,8,15,2,11,'2021-03-10 09:40:53','2021-03-10 09:40:53'),(14,8,16,1,1,'2021-03-10 09:40:53','2021-03-10 09:40:53');
/*!40000 ALTER TABLE `received_stock_details` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `received_stocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `received_stocks` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `purchase_order_id` bigint(20) unsigned NOT NULL,
  `supplier_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `received_stocks_purchase_order_id_foreign` (`purchase_order_id`),
  KEY `received_stocks_supplier_id_foreign` (`supplier_id`),
  CONSTRAINT `received_stocks_purchase_order_id_foreign` FOREIGN KEY (`purchase_order_id`) REFERENCES `purchase_order` (`id`) ON DELETE CASCADE,
  CONSTRAINT `received_stocks_supplier_id_foreign` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `received_stocks` WRITE;
/*!40000 ALTER TABLE `received_stocks` DISABLE KEYS */;
INSERT INTO `received_stocks` VALUES (1,1,1,'2021-03-09 13:28:23','2021-03-09 13:28:23'),(2,2,1,'2021-03-10 08:35:20','2021-03-10 08:35:20'),(3,3,1,'2021-03-10 08:39:40','2021-03-10 08:39:40'),(4,4,1,'2021-03-10 09:03:16','2021-03-10 09:03:16'),(5,4,1,'2021-03-10 09:33:18','2021-03-10 09:33:18'),(6,4,1,'2021-03-10 09:37:19','2021-03-10 09:37:19'),(7,5,1,'2021-03-10 09:38:39','2021-03-10 09:38:39'),(8,5,1,'2021-03-10 09:40:53','2021-03-10 09:40:53');
/*!40000 ALTER TABLE `received_stocks` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
INSERT INTO `role_has_permissions` VALUES (1,1),(2,1),(2,2),(2,3),(3,1),(4,1),(5,1),(6,1),(7,1),(8,1),(9,1),(10,1),(11,1),(12,1),(13,1),(14,1),(15,1),(16,1),(17,1),(17,3),(18,1),(19,1),(20,1),(21,1),(21,2),(21,3),(22,1),(22,2),(22,3);
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Super Admin','api','2021-03-09 09:42:41',NULL),(2,'Cashier','api','2021-03-09 11:46:16','2021-03-09 11:46:16'),(3,'Manager','api','2021-03-09 12:27:04','2021-03-09 12:27:04'),(4,'Special role','api','2021-03-09 12:51:12','2021-03-09 12:51:12');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sales` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `cashier_id` bigint(20) unsigned NOT NULL,
  `customer_id` bigint(20) unsigned NOT NULL,
  `pos_id` bigint(20) unsigned NOT NULL,
  `payment_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sales` WRITE;
/*!40000 ALTER TABLE `sales` DISABLE KEYS */;
INSERT INTO `sales` VALUES (1,1,1,1,'cash','2021-03-10 06:35:19','2021-03-10 06:35:19'),(2,1,1,2,'credit','2021-03-10 07:55:05','2021-03-10 07:55:05'),(3,1,1,4,'cash','2021-03-10 08:08:05','2021-03-10 08:08:05');
/*!40000 ALTER TABLE `sales` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sales_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sales_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `sales_id` bigint(20) unsigned NOT NULL,
  `pos_details_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `quantity` int(10) unsigned NOT NULL DEFAULT 1,
  `price` double(20,2) unsigned NOT NULL DEFAULT 0.00,
  `unit_of_measurement` char(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'each',
  `sub_total` double(20,2) unsigned NOT NULL DEFAULT 0.00,
  `discount` double(20,2) unsigned NOT NULL DEFAULT 0.00,
  `tax` double(20,2) unsigned NOT NULL DEFAULT 0.00,
  `total` double(20,2) unsigned NOT NULL DEFAULT 0.00,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sales_details_sales_id_foreign` (`sales_id`),
  KEY `sales_details_pos_details_id_foreign` (`pos_details_id`),
  CONSTRAINT `sales_details_pos_details_id_foreign` FOREIGN KEY (`pos_details_id`) REFERENCES `pos_details` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sales_details_sales_id_foreign` FOREIGN KEY (`sales_id`) REFERENCES `sales` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sales_details` WRITE;
/*!40000 ALTER TABLE `sales_details` DISABLE KEYS */;
INSERT INTO `sales_details` VALUES (1,1,1,1,5,1200.50,'each',6002.50,600.25,720.30,6122.55,'2021-03-10 06:35:19',NULL),(2,2,4,1,2,1200.50,'each',2401.00,0.00,288.12,2689.12,'2021-03-10 07:55:05',NULL),(3,3,9,1,111,1200.50,'each',133255.50,0.00,15990.66,149246.16,'2021-03-10 08:08:05',NULL);
/*!40000 ALTER TABLE `sales_details` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sales_return_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sales_return_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `sales_return_id` bigint(20) unsigned NOT NULL,
  `pos_details_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `defect` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int(10) unsigned NOT NULL DEFAULT 1,
  `price` double(20,2) unsigned NOT NULL DEFAULT 0.00,
  `unit_of_measurement` char(15) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pcs',
  `sub_total` double(20,2) unsigned NOT NULL DEFAULT 0.00,
  `discount` double(20,2) unsigned NOT NULL DEFAULT 0.00,
  `tax` double(20,2) unsigned NOT NULL DEFAULT 0.00,
  `total` double(20,2) unsigned NOT NULL DEFAULT 0.00,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sales_return_details_pos_details_id_product_id_unique` (`pos_details_id`,`product_id`),
  KEY `sales_return_details_sales_return_id_foreign` (`sales_return_id`),
  CONSTRAINT `sales_return_details_pos_details_id_foreign` FOREIGN KEY (`pos_details_id`) REFERENCES `pos_details` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sales_return_details_sales_return_id_foreign` FOREIGN KEY (`sales_return_id`) REFERENCES `sales_returns` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sales_return_details` WRITE;
/*!40000 ALTER TABLE `sales_return_details` DISABLE KEYS */;
INSERT INTO `sales_return_details` VALUES (1,1,4,1,'Design Defects',1,1200.50,'each',1200.50,0.00,144.06,1344.56,'2021-03-10 10:01:08','2021-03-10 10:01:08');
/*!40000 ALTER TABLE `sales_return_details` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sales_returns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sales_returns` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `pos_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sales_returns_pos_id_foreign` (`pos_id`),
  CONSTRAINT `sales_returns_pos_id_foreign` FOREIGN KEY (`pos_id`) REFERENCES `pos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sales_returns` WRITE;
/*!40000 ALTER TABLE `sales_returns` DISABLE KEYS */;
INSERT INTO `sales_returns` VALUES (1,1,2,'2021-03-10 10:01:08','2021-03-10 10:01:08');
/*!40000 ALTER TABLE `sales_returns` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `stock_adjustment_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stock_adjustment_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `stock_adjustment_id` bigint(20) unsigned NOT NULL,
  `stock_id` bigint(20) unsigned NOT NULL,
  `in_stock` int(10) unsigned NOT NULL DEFAULT 0,
  `added_stock` int(10) unsigned NOT NULL DEFAULT 0,
  `removed_stock` int(10) unsigned NOT NULL DEFAULT 0,
  `counted_stock` int(10) unsigned NOT NULL DEFAULT 0,
  `stock_after` int(10) unsigned NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `stock_adjustment_details_stock_adjustment_id_foreign` (`stock_adjustment_id`),
  KEY `stock_adjustment_details_stock_id_foreign` (`stock_id`),
  CONSTRAINT `stock_adjustment_details_stock_adjustment_id_foreign` FOREIGN KEY (`stock_adjustment_id`) REFERENCES `stock_adjustments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `stock_adjustment_details_stock_id_foreign` FOREIGN KEY (`stock_id`) REFERENCES `stocks` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `stock_adjustment_details` WRITE;
/*!40000 ALTER TABLE `stock_adjustment_details` DISABLE KEYS */;
INSERT INTO `stock_adjustment_details` VALUES (1,1,1,0,10,0,0,110,'2021-03-09 13:09:52','2021-03-09 13:09:52');
/*!40000 ALTER TABLE `stock_adjustment_details` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `stock_adjustments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stock_adjustments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `adjusted_by` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reason` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `stock_adjustments` WRITE;
/*!40000 ALTER TABLE `stock_adjustments` DISABLE KEYS */;
INSERT INTO `stock_adjustments` VALUES (1,'admin','Received items','2021-03-09 13:09:52','2021-03-09 13:09:52');
/*!40000 ALTER TABLE `stock_adjustments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `stocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stocks` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint(20) unsigned NOT NULL,
  `supplier_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `in_stock` int(10) unsigned NOT NULL DEFAULT 0,
  `bad_order_stock` int(10) unsigned NOT NULL DEFAULT 0,
  `stock_in` int(10) unsigned NOT NULL DEFAULT 0,
  `stock_out` int(10) unsigned NOT NULL DEFAULT 0,
  `minimum_reorder_level` int(10) unsigned NOT NULL DEFAULT 0,
  `incoming` int(10) unsigned NOT NULL DEFAULT 0,
  `default_purchase_costs` double(10,2) unsigned NOT NULL DEFAULT 0.00,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `stocks_product_id_unique` (`product_id`),
  CONSTRAINT `stocks_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=96 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `stocks` WRITE;
/*!40000 ALTER TABLE `stocks` DISABLE KEYS */;
INSERT INTO `stocks` VALUES (1,1,1,5,24,63,168,10,2,100.00,'2021-03-09 11:00:29','2021-03-09 11:23:14'),(17,2,0,13,0,12,0,10,2,12.00,'2021-03-10 08:45:14','2021-03-10 08:45:14'),(18,3,1,991,0,2,11,10,2,12.00,'2021-03-10 08:48:46','2021-03-10 08:48:46'),(19,4,1,1003,0,2,0,10,0,12.00,'2021-03-10 08:52:12','2021-03-10 08:52:12'),(20,5,1,2,0,0,0,10,10,12.00,'2021-03-10 09:00:43','2021-03-10 09:01:12');
/*!40000 ALTER TABLE `stocks` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `suppliers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `website` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `main_address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `optional_address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `zipcode` char(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `province` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `suppliers_contact_unique` (`contact`),
  UNIQUE KEY `suppliers_email_unique` (`email`),
  UNIQUE KEY `suppliers_phone_unique` (`phone`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `suppliers` WRITE;
/*!40000 ALTER TABLE `suppliers` DISABLE KEYS */;
INSERT INTO `suppliers` VALUES (1,'Nike Factory','123123123123','nikefactory@gmail.com','12312312313',NULL,'USA',NULL,'North Carolina','4123','United States of America','GGs','2021-03-09 11:18:20','2021-03-09 11:18:36');
/*!40000 ALTER TABLE `suppliers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `system_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_permission` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `permission_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `system_permission_permission_id_foreign` (`permission_id`),
  CONSTRAINT `system_permission_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `system_permission` WRITE;
/*!40000 ALTER TABLE `system_permission` DISABLE KEYS */;
INSERT INTO `system_permission` VALUES (1,'POS',2,'2021-03-09 11:44:57',NULL),(2,'POS',17,'2021-03-09 11:44:57',NULL),(3,'Back Office',1,'2021-03-09 11:44:57',NULL),(4,'Back Office',3,'2021-03-09 11:44:57',NULL),(5,'Back Office',4,'2021-03-09 11:44:57',NULL),(6,'Back Office',5,'2021-03-09 11:44:57',NULL),(7,'Back Office',6,'2021-03-09 11:44:57',NULL),(8,'Back Office',7,'2021-03-09 11:44:57',NULL),(9,'Back Office',9,'2021-03-09 11:44:57',NULL),(10,'Back Office',10,'2021-03-09 11:44:57',NULL),(11,'Back Office',11,'2021-03-09 11:44:57',NULL),(12,'Back Office',12,'2021-03-09 11:44:57',NULL),(13,'Back Office',13,'2021-03-09 11:44:57',NULL),(14,'Back Office',16,'2021-03-09 11:44:57',NULL),(15,'Back Office',18,'2021-03-09 11:44:57',NULL),(16,'Back Office',19,'2021-03-09 11:44:57',NULL);
/*!40000 ALTER TABLE `system_permission` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','genephillip222@gmail.com',NULL,'$2y$10$35nuXqH3J5bA.VWCUc37qOsg3hRp36PH//t.JrRlq0dxBdz9IoAXG',NULL,NULL,'2021-03-09 09:42:24','2021-03-10 08:10:25'),(2,'James Chadwick','james@yahoo.com',NULL,'$2y$10$BKIKbWBGtPbLCEqgOGSxhu4igk6JVepA4H4ZO6m3Od0aqzbSq9W62',NULL,NULL,'2021-03-09 12:32:06','2021-03-09 12:32:06');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

