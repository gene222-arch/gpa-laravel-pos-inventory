<?php

namespace App\Http\Requests\Customer;

use App\Http\Requests\BaseRequest;

class DeleteRequest extends BaseRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'customer_ids.*' => ['required', 'integer', 'distinct', 'exists:customers,id'],
        ];
    }
}
