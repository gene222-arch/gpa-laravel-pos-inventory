<?php

namespace App\Traits\Users;

trait CashierServices
{

}
