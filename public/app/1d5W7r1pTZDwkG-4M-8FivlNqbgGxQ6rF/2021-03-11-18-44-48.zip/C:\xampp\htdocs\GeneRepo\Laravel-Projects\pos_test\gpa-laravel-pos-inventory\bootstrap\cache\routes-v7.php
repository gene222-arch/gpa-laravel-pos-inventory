<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/oauth/authorize' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'passport.authorizations.authorize',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'passport.authorizations.approve',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'passport.authorizations.deny',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/oauth/token' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'passport.token',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/oauth/tokens' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'passport.tokens.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/oauth/token/refresh' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'passport.token.refresh',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/oauth/clients' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'passport.clients.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'passport.clients.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/oauth/scopes' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'passport.scopes.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/oauth/personal-access-tokens' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'passport.personal.tokens.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'passport.personal.tokens.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/auth/register' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::57Gyj1EQdR8wmVYr',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/auth/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'login',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/forgot-password/email' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::skS1HXxpzVkEJKkm',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/forgot-password/reset' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ipqN459wz7grzhEf',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cFZ6fk9RX8u3o8xs',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/account/auth-user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::m7p3rkjdHlBGkUUF',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/account/check-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::O18PGO6jCkE72pkv',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/account/password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Kg1mw7Sygp3PrPBV',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/account/name' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dgSoTIy13csAXzpO',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/account/email' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Jhw2iRSBh8DxijKM',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/roles' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nk33QBdv94Zvyp3Q',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/permissions' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wSUHomu9cmVlWIm5',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/permissions/auth' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FARMbYdWYyOiG0Un',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/dashboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::sRFZBV4pDpp9USYR',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/products' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::aVJkitetbyagY0n0',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ggdlBX6pZUG3c7Tv',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::juAASzyY0dxDnfqM',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        3 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zK3fn1AiFr7g1Wwf',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/products/details' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9HzHqCjbMn7Gff8x',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/products/image-upload' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3ZKXRPM60QhuOIkD',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/products/to-purchase' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XSwIvDmQJqCOHqsl',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/products/filter' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rTQVVDz8mLsOlqge',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/categories' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::X09MOYzBUVVQvbJR',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yNle8eA1TaJGcfqu',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bDZ3v5w8GK9bTSi9',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        3 => 
        array (
          0 => 
          array (
            '_route' => 'generated::381GhTRSB6RDGCEm',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/categories/details' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BWAk1LBAeyj9wD2l',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/discounts' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::R9f3HcT6fzzkGlR8',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wWKxKeWQNIfsldhq',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xZE5KqRSBHCZeEHw',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        3 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hmEXa8Peyi6LOjBJ',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/discounts/details' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Pf3LknhorFRL1bSk',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/suppliers' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BCyznYcj57sEgrdF',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IVw9z8xVrN6Kx4Sb',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::eFk0Go9nnQb0ZIEA',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        3 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lRSWU2PTDa3E4fLK',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/suppliers/supplier-details' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pAcDU34NC1jVTWiR',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/stocks/stock-adjustments' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xMhf4ro1QNnfEXay',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/stocks/stock-adjustments/products' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qEsEgdzwpf3XohOs',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/stocks/stock-adjustments/stock' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fcmpGOAZe7mH5S1e',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/stocks/stock-adjustments/details' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::awCii8BoAY8JZpU6',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/stocks/stock-adjustment/received-items' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8EZZLkM7OieIw16q',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/stocks/stock-adjustment/inventory-count' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::spNhPZSBB4Brcohq',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/stocks/stock-adjustment/loss-damage' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::AE51whBqRdoCXav2',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/purchase-orders' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MYnOjnrUPtECS9e9',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Z1TMiKPFzfxb1owX',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wsJojcXxw8BGjfz2',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        3 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mjpsaLEJ2YlsC2f7',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/purchase-orders/products' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uETCA9s5270FFTyw',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6F5EiPDeGxmSm1sF',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/purchase-orders/suppliers' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8AjeVWwoXQWM0Cer',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/purchase-orders/filtered' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RSiLY70gmtae8o9a',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/purchase-orders/purchase-order-details' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZvxsVqfj1BU0cfiD',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/purchase-orders/product' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7GBiNBNxOUNWIfSG',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/purchase-orders/purchase-order-details/to-receive' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bFjjkw9HidB3gN9D',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/purchase-orders/received-stocks-details' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GDO0Z8Ms6ZJr6txv',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/purchase-orders/to-receive' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::75asgZX3WzWBUYuR',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/purchase-orders/mark-all-as-received' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::U75Lcx4yRsNcIu7F',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/purchase-orders/cancel' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lhgWvy2BluTMdxYZ',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/purchase-orders/mail-supplier' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GKmXfxmR49yuqaKY',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/bad-orders' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yD4wE4XghP3bd7zm',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VeOwxGTtKT7vzpR0',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zZgQEGB4XHtambh8',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        3 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bhw4StaG8kT5nLNM',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/bad-orders/purchase-orders' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tGWnB7RCR8wZviwh',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/bad-orders/purchase-order' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NVH8jzvJz7VFx57m',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/bad-orders/details' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::49PruAg0ssBBIdd9',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/customers' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6kpoME6NuF3oVrGm',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2Wzr2uVyKH9EYHty',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5MuBA2guKTKMfOD6',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        3 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1kP6X3EL16vRPfsQ',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/customers/details' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nL2rre2oAbcp56h0',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/access-rights' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7e5CggF7H0KTetQd',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oeqh2wQYdvZYmb5y',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qEKcPhj0unLhuRYE',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        3 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JVg6vvzkX1ArLcru',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/access-rights/details' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SMekl7MU7kYGO007',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/employees' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2gQOxgrCJsJnzHMd',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lABvnN5WNGYTKz5b',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::aky783XmjMBPSnGF',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        3 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oUF9nLIkUK4Y21Jd',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/employees/access_rights' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SZ66mVsqjsydEOH7',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/employees/details' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rEMNPUZYlWcOIWRV',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/pos/order-lists' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zr7OO5nHEni8Xa1D',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/pos/categories' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QCfmHzhd4Buk75zz',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/pos/customers' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wDNiUx4yrSLD4C2K',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/pos/customer' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qvWelTwK43lKxxfi',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/pos/discounts' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::e9K1zb29OVDH1dhh',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/pos/products' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Gh278TPbdpvVPqXf',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/pos/order-lists/filtered' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FRnIiicQ4mUW4rru',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/pos/cart-details' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zsZBNlduREa3zvAF',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/pos/add-to-cart' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mRrbdzG3X4VUMfZU',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/pos/to-pay' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::h3Lz6UKvfnBLyoPP',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/pos/process-payment' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::AaFJpnLGnLqk4QRa',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/pos/discount-all' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Sw7DvxhPJmCvX3dI',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xEKLyyVNxKmjE9GN',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/pos/discount/item-quantity' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LXZ2SrvFMoC7yW4J',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/pos/cancel-orders' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CjsntNRAFTQ4RU5p',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/pos/items' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fdRfoafKs0OUggzu',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/receipts' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::aeDzAV4IDM8NOK1X',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/receipts/with-details' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yqWmHkPNvZRiMafr',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/invoices' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oVSol5qDUHwZQ8ha',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oXKushkXFoW2iTpz',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::P2Pk87rXzVSLgpKV',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/invoices/details' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oBWSPOnT9MFqGDYr',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/sales-returns' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::caCHUSq33sAwtKLl',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PVh1k8ESodtlEKhu',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5WTyiUKtk4CxKbkI',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        3 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ODu4aobmbFJdCTOe',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/sales-returns/customer-orders' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::m24kdOtMgtn8k2lS',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/sales-returns/customer-order' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::eTtrL75S0pEQ2BEV',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/sales-returns/details' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::36EPg9rI4jcD9LZc',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/sales-returns/items' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hAB1fBE068kInvJo',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/transactions/customer-orders' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jGyzhJV7SrAZlVEs',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/transactions/invoices' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oUcumXidCforXuAj',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/transactions/purchase-orders' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::sW6uwKs7E2huIXYv',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/transactions/received-stocks' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::q0skXjAY9w1UP4Gg',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/reports/general' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::eyOiM2BpKREzHmnB',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/reports/sales-by-item' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lzrwXv8rw0BHl4zK',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/reports/sales-by-category' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3TAcigGLQ11k9l7p',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/reports/sales-by-payment-type' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qRCZlmPcbRE2hXiF',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/reports/sales-by-employee' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MK4gMYZAcdczp2qg',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/excel-export/invoices' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dWeHPT9g4t3rIBiA',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/excel-export/purchase-orders' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::U99df2olj1sVHEVe',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/excel-export/payments' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OUY6CAnWKjcA96xn',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/excel-export/customers' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kHFirSDvtexRdo8j',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/excel-export/products' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZULomzY50yUWguh5',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/excel-export/bad-orders' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::eAUWMyfcxUYURpao',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/excel-export/sales-returns' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vM1JROXjq0Ggwqya',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/csv-export/invoices' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::33g41Kp1VlbTF8nj',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/csv-export/purchase-orders' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XPyhzylYI6bpXGT4',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/csv-export/payments' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Gc9yh62yYdMvY0IX',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/csv-export/customers' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::itndjTiRXN9LrI36',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/csv-export/products' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vVXRR6rJp4ZZZw9k',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/csv-export/bad-orders' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Ut6ni5tw47QRNKnm',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/csv-export/sales-returns' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::88OadaUSlcqCya1I',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/import/products' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CJkQj7qh008WHdsC',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::f39dHfwHlLs30UiD',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/oauth/(?|tokens/([^/]++)(*:32)|clients/([^/]++)(?|(*:58))|personal\\-access\\-tokens/([^/]++)(*:99))|/api/(?|pdf\\-(?|print/sales\\-receipt/([^/]++)(*:152)|export/(?|invoices/([^/]++)(*:187)|p(?|urchase\\-order/([^/]++)(*:222)|os\\-payment/([^/]++)(*:250))))|csv\\-export/purchase\\-order/([^/]++)(*:297)))/?$}sDu',
    ),
    3 => 
    array (
      32 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'passport.tokens.destroy',
          ),
          1 => 
          array (
            0 => 'token_id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      58 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'passport.clients.update',
          ),
          1 => 
          array (
            0 => 'client_id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'passport.clients.destroy',
          ),
          1 => 
          array (
            0 => 'client_id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      99 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'passport.personal.tokens.destroy',
          ),
          1 => 
          array (
            0 => 'token_id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      152 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XPqSPo1kNi8sOGSE',
          ),
          1 => 
          array (
            0 => 'sale',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      187 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::g6h3DXgZ1NonDQlg',
          ),
          1 => 
          array (
            0 => 'invoice',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      222 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nToOEqEMNxdffDv6',
          ),
          1 => 
          array (
            0 => 'purchaseOrder',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      250 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ygJ5eKcLCCK4aKKN',
          ),
          1 => 
          array (
            0 => 'payment',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      297 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MC50M8EtG6simGx7',
          ),
          1 => 
          array (
            0 => 'purchaseOrder',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'passport.authorizations.authorize' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'oauth/authorize',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => '\\Laravel\\Passport\\Http\\Controllers\\AuthorizationController@authorize',
        'as' => 'passport.authorizations.authorize',
        'controller' => '\\Laravel\\Passport\\Http\\Controllers\\AuthorizationController@authorize',
        'namespace' => '\\Laravel\\Passport\\Http\\Controllers',
        'prefix' => 'oauth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'passport.authorizations.approve' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'oauth/authorize',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => '\\Laravel\\Passport\\Http\\Controllers\\ApproveAuthorizationController@approve',
        'as' => 'passport.authorizations.approve',
        'controller' => '\\Laravel\\Passport\\Http\\Controllers\\ApproveAuthorizationController@approve',
        'namespace' => '\\Laravel\\Passport\\Http\\Controllers',
        'prefix' => 'oauth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'passport.authorizations.deny' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'oauth/authorize',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => '\\Laravel\\Passport\\Http\\Controllers\\DenyAuthorizationController@deny',
        'as' => 'passport.authorizations.deny',
        'controller' => '\\Laravel\\Passport\\Http\\Controllers\\DenyAuthorizationController@deny',
        'namespace' => '\\Laravel\\Passport\\Http\\Controllers',
        'prefix' => 'oauth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'passport.token' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'oauth/token',
      'action' => 
      array (
        'uses' => '\\Laravel\\Passport\\Http\\Controllers\\AccessTokenController@issueToken',
        'as' => 'passport.token',
        'middleware' => 'throttle',
        'controller' => '\\Laravel\\Passport\\Http\\Controllers\\AccessTokenController@issueToken',
        'namespace' => '\\Laravel\\Passport\\Http\\Controllers',
        'prefix' => 'oauth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'passport.tokens.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'oauth/tokens',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => '\\Laravel\\Passport\\Http\\Controllers\\AuthorizedAccessTokenController@forUser',
        'as' => 'passport.tokens.index',
        'controller' => '\\Laravel\\Passport\\Http\\Controllers\\AuthorizedAccessTokenController@forUser',
        'namespace' => '\\Laravel\\Passport\\Http\\Controllers',
        'prefix' => 'oauth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'passport.tokens.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'oauth/tokens/{token_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => '\\Laravel\\Passport\\Http\\Controllers\\AuthorizedAccessTokenController@destroy',
        'as' => 'passport.tokens.destroy',
        'controller' => '\\Laravel\\Passport\\Http\\Controllers\\AuthorizedAccessTokenController@destroy',
        'namespace' => '\\Laravel\\Passport\\Http\\Controllers',
        'prefix' => 'oauth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'passport.token.refresh' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'oauth/token/refresh',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => '\\Laravel\\Passport\\Http\\Controllers\\TransientTokenController@refresh',
        'as' => 'passport.token.refresh',
        'controller' => '\\Laravel\\Passport\\Http\\Controllers\\TransientTokenController@refresh',
        'namespace' => '\\Laravel\\Passport\\Http\\Controllers',
        'prefix' => 'oauth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'passport.clients.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'oauth/clients',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => '\\Laravel\\Passport\\Http\\Controllers\\ClientController@forUser',
        'as' => 'passport.clients.index',
        'controller' => '\\Laravel\\Passport\\Http\\Controllers\\ClientController@forUser',
        'namespace' => '\\Laravel\\Passport\\Http\\Controllers',
        'prefix' => 'oauth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'passport.clients.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'oauth/clients',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => '\\Laravel\\Passport\\Http\\Controllers\\ClientController@store',
        'as' => 'passport.clients.store',
        'controller' => '\\Laravel\\Passport\\Http\\Controllers\\ClientController@store',
        'namespace' => '\\Laravel\\Passport\\Http\\Controllers',
        'prefix' => 'oauth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'passport.clients.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'oauth/clients/{client_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => '\\Laravel\\Passport\\Http\\Controllers\\ClientController@update',
        'as' => 'passport.clients.update',
        'controller' => '\\Laravel\\Passport\\Http\\Controllers\\ClientController@update',
        'namespace' => '\\Laravel\\Passport\\Http\\Controllers',
        'prefix' => 'oauth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'passport.clients.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'oauth/clients/{client_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => '\\Laravel\\Passport\\Http\\Controllers\\ClientController@destroy',
        'as' => 'passport.clients.destroy',
        'controller' => '\\Laravel\\Passport\\Http\\Controllers\\ClientController@destroy',
        'namespace' => '\\Laravel\\Passport\\Http\\Controllers',
        'prefix' => 'oauth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'passport.scopes.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'oauth/scopes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => '\\Laravel\\Passport\\Http\\Controllers\\ScopeController@all',
        'as' => 'passport.scopes.index',
        'controller' => '\\Laravel\\Passport\\Http\\Controllers\\ScopeController@all',
        'namespace' => '\\Laravel\\Passport\\Http\\Controllers',
        'prefix' => 'oauth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'passport.personal.tokens.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'oauth/personal-access-tokens',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => '\\Laravel\\Passport\\Http\\Controllers\\PersonalAccessTokenController@forUser',
        'as' => 'passport.personal.tokens.index',
        'controller' => '\\Laravel\\Passport\\Http\\Controllers\\PersonalAccessTokenController@forUser',
        'namespace' => '\\Laravel\\Passport\\Http\\Controllers',
        'prefix' => 'oauth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'passport.personal.tokens.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'oauth/personal-access-tokens',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => '\\Laravel\\Passport\\Http\\Controllers\\PersonalAccessTokenController@store',
        'as' => 'passport.personal.tokens.store',
        'controller' => '\\Laravel\\Passport\\Http\\Controllers\\PersonalAccessTokenController@store',
        'namespace' => '\\Laravel\\Passport\\Http\\Controllers',
        'prefix' => 'oauth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'passport.personal.tokens.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'oauth/personal-access-tokens/{token_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => '\\Laravel\\Passport\\Http\\Controllers\\PersonalAccessTokenController@destroy',
        'as' => 'passport.personal.tokens.destroy',
        'controller' => '\\Laravel\\Passport\\Http\\Controllers\\PersonalAccessTokenController@destroy',
        'namespace' => '\\Laravel\\Passport\\Http\\Controllers',
        'prefix' => 'oauth',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::57Gyj1EQdR8wmVYr' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/auth/register',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Auth\\RegisterController@register',
        'controller' => 'App\\Http\\Controllers\\Api\\Auth\\RegisterController@register',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::57Gyj1EQdR8wmVYr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'login' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/auth/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Auth\\LoginController@login',
        'controller' => 'App\\Http\\Controllers\\Api\\Auth\\LoginController@login',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::skS1HXxpzVkEJKkm' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/forgot-password/email',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Auth\\ForgotPasswordController@sendResetLinkEmail',
        'controller' => 'App\\Http\\Controllers\\Api\\Auth\\ForgotPasswordController@sendResetLinkEmail',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::skS1HXxpzVkEJKkm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ipqN459wz7grzhEf' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/forgot-password/reset',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Auth\\ResetPasswordController@reset',
        'controller' => 'App\\Http\\Controllers\\Api\\Auth\\ResetPasswordController@reset',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::ipqN459wz7grzhEf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::cFZ6fk9RX8u3o8xs' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'api',
          2 => 'auth:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Auth\\LoginController@logout',
        'controller' => 'App\\Http\\Controllers\\Api\\Auth\\LoginController@logout',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::cFZ6fk9RX8u3o8xs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::m7p3rkjdHlBGkUUF' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/account/auth-user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Auth\\AuthController@showAuthenticatedUser',
        'controller' => 'App\\Http\\Controllers\\Api\\Auth\\AuthController@showAuthenticatedUser',
        'namespace' => NULL,
        'prefix' => 'api/account',
        'where' => 
        array (
        ),
        'as' => 'generated::m7p3rkjdHlBGkUUF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::O18PGO6jCkE72pkv' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/account/check-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Auth\\AuthController@checkPassword',
        'controller' => 'App\\Http\\Controllers\\Api\\Auth\\AuthController@checkPassword',
        'namespace' => NULL,
        'prefix' => 'api/account',
        'where' => 
        array (
        ),
        'as' => 'generated::O18PGO6jCkE72pkv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Kg1mw7Sygp3PrPBV' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/account/password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Auth\\AuthController@updatePassword',
        'controller' => 'App\\Http\\Controllers\\Api\\Auth\\AuthController@updatePassword',
        'namespace' => NULL,
        'prefix' => 'api/account',
        'where' => 
        array (
        ),
        'as' => 'generated::Kg1mw7Sygp3PrPBV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::dgSoTIy13csAXzpO' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/account/name',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Auth\\AuthController@updateName',
        'controller' => 'App\\Http\\Controllers\\Api\\Auth\\AuthController@updateName',
        'namespace' => NULL,
        'prefix' => 'api/account',
        'where' => 
        array (
        ),
        'as' => 'generated::dgSoTIy13csAXzpO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Jhw2iRSBh8DxijKM' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/account/email',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Auth\\AuthController@updateEmail',
        'controller' => 'App\\Http\\Controllers\\Api\\Auth\\AuthController@updateEmail',
        'namespace' => NULL,
        'prefix' => 'api/account',
        'where' => 
        array (
        ),
        'as' => 'generated::Jhw2iRSBh8DxijKM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::nk33QBdv94Zvyp3Q' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/roles',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\RolesPermission\\RolesController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\RolesPermission\\RolesController@index',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::nk33QBdv94Zvyp3Q',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::wSUHomu9cmVlWIm5' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/permissions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\RolesPermission\\PermissionsController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\RolesPermission\\PermissionsController@index',
        'namespace' => NULL,
        'prefix' => 'api/permissions',
        'where' => 
        array (
        ),
        'as' => 'generated::wSUHomu9cmVlWIm5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::FARMbYdWYyOiG0Un' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/permissions/auth',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\RolesPermission\\PermissionsController@showAuthenticatedUserPermissions',
        'controller' => 'App\\Http\\Controllers\\Api\\RolesPermission\\PermissionsController@showAuthenticatedUserPermissions',
        'namespace' => NULL,
        'prefix' => 'api/permissions',
        'where' => 
        array (
        ),
        'as' => 'generated::FARMbYdWYyOiG0Un',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::sRFZBV4pDpp9USYR' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/dashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Dashboard\\DashboardController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\Dashboard\\DashboardController@index',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::sRFZBV4pDpp9USYR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::aVJkitetbyagY0n0' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/products',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Products\\ProductsController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\Products\\ProductsController@index',
        'namespace' => NULL,
        'prefix' => 'api/products',
        'where' => 
        array (
        ),
        'as' => 'generated::aVJkitetbyagY0n0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::9HzHqCjbMn7Gff8x' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/products/details',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Products\\ProductsController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\Products\\ProductsController@show',
        'namespace' => NULL,
        'prefix' => 'api/products',
        'where' => 
        array (
        ),
        'as' => 'generated::9HzHqCjbMn7Gff8x',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::3ZKXRPM60QhuOIkD' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/products/image-upload',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Products\\ProductsController@upload',
        'controller' => 'App\\Http\\Controllers\\Api\\Products\\ProductsController@upload',
        'namespace' => NULL,
        'prefix' => 'api/products',
        'where' => 
        array (
        ),
        'as' => 'generated::3ZKXRPM60QhuOIkD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::XSwIvDmQJqCOHqsl' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/products/to-purchase',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Products\\ProductsController@showProductToPurchase',
        'controller' => 'App\\Http\\Controllers\\Api\\Products\\ProductsController@showProductToPurchase',
        'namespace' => NULL,
        'prefix' => 'api/products',
        'where' => 
        array (
        ),
        'as' => 'generated::XSwIvDmQJqCOHqsl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::rTQVVDz8mLsOlqge' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/products/filter',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Products\\ProductsController@showFilteredProducts',
        'controller' => 'App\\Http\\Controllers\\Api\\Products\\ProductsController@showFilteredProducts',
        'namespace' => NULL,
        'prefix' => 'api/products',
        'where' => 
        array (
        ),
        'as' => 'generated::rTQVVDz8mLsOlqge',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ggdlBX6pZUG3c7Tv' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/products',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Products\\ProductsController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\Products\\ProductsController@store',
        'namespace' => NULL,
        'prefix' => 'api/products',
        'where' => 
        array (
        ),
        'as' => 'generated::ggdlBX6pZUG3c7Tv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::juAASzyY0dxDnfqM' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/products',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Products\\ProductsController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\Products\\ProductsController@update',
        'namespace' => NULL,
        'prefix' => 'api/products',
        'where' => 
        array (
        ),
        'as' => 'generated::juAASzyY0dxDnfqM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::zK3fn1AiFr7g1Wwf' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/products',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Products\\ProductsController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\Products\\ProductsController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/products',
        'where' => 
        array (
        ),
        'as' => 'generated::zK3fn1AiFr7g1Wwf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::X09MOYzBUVVQvbJR' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/categories',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Products\\CategoriesController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\Products\\CategoriesController@index',
        'namespace' => NULL,
        'prefix' => 'api/categories',
        'where' => 
        array (
        ),
        'as' => 'generated::X09MOYzBUVVQvbJR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::BWAk1LBAeyj9wD2l' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/categories/details',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Products\\CategoriesController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\Products\\CategoriesController@show',
        'namespace' => NULL,
        'prefix' => 'api/categories',
        'where' => 
        array (
        ),
        'as' => 'generated::BWAk1LBAeyj9wD2l',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::yNle8eA1TaJGcfqu' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/categories',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Products\\CategoriesController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\Products\\CategoriesController@store',
        'namespace' => NULL,
        'prefix' => 'api/categories',
        'where' => 
        array (
        ),
        'as' => 'generated::yNle8eA1TaJGcfqu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::bDZ3v5w8GK9bTSi9' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/categories',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Products\\CategoriesController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\Products\\CategoriesController@update',
        'namespace' => NULL,
        'prefix' => 'api/categories',
        'where' => 
        array (
        ),
        'as' => 'generated::bDZ3v5w8GK9bTSi9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::381GhTRSB6RDGCEm' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/categories',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Products\\CategoriesController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\Products\\CategoriesController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/categories',
        'where' => 
        array (
        ),
        'as' => 'generated::381GhTRSB6RDGCEm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::R9f3HcT6fzzkGlR8' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/discounts',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Products\\DiscountsController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\Products\\DiscountsController@index',
        'namespace' => NULL,
        'prefix' => 'api/discounts',
        'where' => 
        array (
        ),
        'as' => 'generated::R9f3HcT6fzzkGlR8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Pf3LknhorFRL1bSk' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/discounts/details',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Products\\DiscountsController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\Products\\DiscountsController@show',
        'namespace' => NULL,
        'prefix' => 'api/discounts',
        'where' => 
        array (
        ),
        'as' => 'generated::Pf3LknhorFRL1bSk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::wWKxKeWQNIfsldhq' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/discounts',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Products\\DiscountsController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\Products\\DiscountsController@store',
        'namespace' => NULL,
        'prefix' => 'api/discounts',
        'where' => 
        array (
        ),
        'as' => 'generated::wWKxKeWQNIfsldhq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::xZE5KqRSBHCZeEHw' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/discounts',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Products\\DiscountsController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\Products\\DiscountsController@update',
        'namespace' => NULL,
        'prefix' => 'api/discounts',
        'where' => 
        array (
        ),
        'as' => 'generated::xZE5KqRSBHCZeEHw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::hmEXa8Peyi6LOjBJ' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/discounts',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Products\\DiscountsController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\Products\\DiscountsController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/discounts',
        'where' => 
        array (
        ),
        'as' => 'generated::hmEXa8Peyi6LOjBJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::BCyznYcj57sEgrdF' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/suppliers',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\SuppliersController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\SuppliersController@index',
        'namespace' => NULL,
        'prefix' => 'api/suppliers',
        'where' => 
        array (
        ),
        'as' => 'generated::BCyznYcj57sEgrdF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::pAcDU34NC1jVTWiR' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/suppliers/supplier-details',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\SuppliersController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\SuppliersController@show',
        'namespace' => NULL,
        'prefix' => 'api/suppliers',
        'where' => 
        array (
        ),
        'as' => 'generated::pAcDU34NC1jVTWiR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::IVw9z8xVrN6Kx4Sb' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/suppliers',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\SuppliersController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\SuppliersController@store',
        'namespace' => NULL,
        'prefix' => 'api/suppliers',
        'where' => 
        array (
        ),
        'as' => 'generated::IVw9z8xVrN6Kx4Sb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::eFk0Go9nnQb0ZIEA' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/suppliers',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\SuppliersController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\SuppliersController@update',
        'namespace' => NULL,
        'prefix' => 'api/suppliers',
        'where' => 
        array (
        ),
        'as' => 'generated::eFk0Go9nnQb0ZIEA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::lRSWU2PTDa3E4fLK' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/suppliers',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\SuppliersController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\SuppliersController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/suppliers',
        'where' => 
        array (
        ),
        'as' => 'generated::lRSWU2PTDa3E4fLK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::xMhf4ro1QNnfEXay' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/stocks/stock-adjustments',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\StockAdjustmentsController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\StockAdjustmentsController@index',
        'namespace' => NULL,
        'prefix' => 'api/stocks',
        'where' => 
        array (
        ),
        'as' => 'generated::xMhf4ro1QNnfEXay',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::qEsEgdzwpf3XohOs' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/stocks/stock-adjustments/products',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\StockAdjustmentsController@indexProducts',
        'controller' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\StockAdjustmentsController@indexProducts',
        'namespace' => NULL,
        'prefix' => 'api/stocks',
        'where' => 
        array (
        ),
        'as' => 'generated::qEsEgdzwpf3XohOs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::fcmpGOAZe7mH5S1e' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/stocks/stock-adjustments/stock',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\StockAdjustmentsController@showStockToAdjust',
        'controller' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\StockAdjustmentsController@showStockToAdjust',
        'namespace' => NULL,
        'prefix' => 'api/stocks',
        'where' => 
        array (
        ),
        'as' => 'generated::fcmpGOAZe7mH5S1e',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::awCii8BoAY8JZpU6' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/stocks/stock-adjustments/details',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\StockAdjustmentsController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\StockAdjustmentsController@show',
        'namespace' => NULL,
        'prefix' => 'api/stocks',
        'where' => 
        array (
        ),
        'as' => 'generated::awCii8BoAY8JZpU6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::8EZZLkM7OieIw16q' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/stocks/stock-adjustment/received-items',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\StockAdjustmentsController@storeReceivedItems',
        'controller' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\StockAdjustmentsController@storeReceivedItems',
        'namespace' => NULL,
        'prefix' => 'api/stocks',
        'where' => 
        array (
        ),
        'as' => 'generated::8EZZLkM7OieIw16q',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::spNhPZSBB4Brcohq' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/stocks/stock-adjustment/inventory-count',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\StockAdjustmentsController@storeInventoryCount',
        'controller' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\StockAdjustmentsController@storeInventoryCount',
        'namespace' => NULL,
        'prefix' => 'api/stocks',
        'where' => 
        array (
        ),
        'as' => 'generated::spNhPZSBB4Brcohq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::AE51whBqRdoCXav2' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/stocks/stock-adjustment/loss-damage',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\StockAdjustmentsController@storeLossDamage',
        'controller' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\StockAdjustmentsController@storeLossDamage',
        'namespace' => NULL,
        'prefix' => 'api/stocks',
        'where' => 
        array (
        ),
        'as' => 'generated::AE51whBqRdoCXav2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::MYnOjnrUPtECS9e9' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/purchase-orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\PurchaseOrdersController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\PurchaseOrdersController@index',
        'namespace' => NULL,
        'prefix' => 'api/purchase-orders',
        'where' => 
        array (
        ),
        'as' => 'generated::MYnOjnrUPtECS9e9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::uETCA9s5270FFTyw' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/purchase-orders/products',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\PurchaseOrdersController@indexProducts',
        'controller' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\PurchaseOrdersController@indexProducts',
        'namespace' => NULL,
        'prefix' => 'api/purchase-orders',
        'where' => 
        array (
        ),
        'as' => 'generated::uETCA9s5270FFTyw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::8AjeVWwoXQWM0Cer' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/purchase-orders/suppliers',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\PurchaseOrdersController@indexSuppliers',
        'controller' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\PurchaseOrdersController@indexSuppliers',
        'namespace' => NULL,
        'prefix' => 'api/purchase-orders',
        'where' => 
        array (
        ),
        'as' => 'generated::8AjeVWwoXQWM0Cer',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::RSiLY70gmtae8o9a' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/purchase-orders/filtered',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\PurchaseOrdersController@filteredIndex',
        'controller' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\PurchaseOrdersController@filteredIndex',
        'namespace' => NULL,
        'prefix' => 'api/purchase-orders',
        'where' => 
        array (
        ),
        'as' => 'generated::RSiLY70gmtae8o9a',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ZvxsVqfj1BU0cfiD' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/purchase-orders/purchase-order-details',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\PurchaseOrdersController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\PurchaseOrdersController@show',
        'namespace' => NULL,
        'prefix' => 'api/purchase-orders',
        'where' => 
        array (
        ),
        'as' => 'generated::ZvxsVqfj1BU0cfiD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::7GBiNBNxOUNWIfSG' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/purchase-orders/product',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\PurchaseOrdersController@showProductToPurchase',
        'controller' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\PurchaseOrdersController@showProductToPurchase',
        'namespace' => NULL,
        'prefix' => 'api/purchase-orders',
        'where' => 
        array (
        ),
        'as' => 'generated::7GBiNBNxOUNWIfSG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::bFjjkw9HidB3gN9D' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/purchase-orders/purchase-order-details/to-receive',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\PurchaseOrdersController@editToReceive',
        'controller' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\PurchaseOrdersController@editToReceive',
        'namespace' => NULL,
        'prefix' => 'api/purchase-orders',
        'where' => 
        array (
        ),
        'as' => 'generated::bFjjkw9HidB3gN9D',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::GDO0Z8Ms6ZJr6txv' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/purchase-orders/received-stocks-details',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\PurchaseOrdersController@showReceivedStocks',
        'controller' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\PurchaseOrdersController@showReceivedStocks',
        'namespace' => NULL,
        'prefix' => 'api/purchase-orders',
        'where' => 
        array (
        ),
        'as' => 'generated::GDO0Z8Ms6ZJr6txv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Z1TMiKPFzfxb1owX' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/purchase-orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\PurchaseOrdersController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\PurchaseOrdersController@store',
        'namespace' => NULL,
        'prefix' => 'api/purchase-orders',
        'where' => 
        array (
        ),
        'as' => 'generated::Z1TMiKPFzfxb1owX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::wsJojcXxw8BGjfz2' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/purchase-orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\PurchaseOrdersController@upsert',
        'controller' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\PurchaseOrdersController@upsert',
        'namespace' => NULL,
        'prefix' => 'api/purchase-orders',
        'where' => 
        array (
        ),
        'as' => 'generated::wsJojcXxw8BGjfz2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::75asgZX3WzWBUYuR' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/purchase-orders/to-receive',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\PurchaseOrdersController@toReceivePurchaseOrder',
        'controller' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\PurchaseOrdersController@toReceivePurchaseOrder',
        'namespace' => NULL,
        'prefix' => 'api/purchase-orders',
        'where' => 
        array (
        ),
        'as' => 'generated::75asgZX3WzWBUYuR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::U75Lcx4yRsNcIu7F' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/purchase-orders/mark-all-as-received',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\PurchaseOrdersController@markAllPurchasedOrderAsReceived',
        'controller' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\PurchaseOrdersController@markAllPurchasedOrderAsReceived',
        'namespace' => NULL,
        'prefix' => 'api/purchase-orders',
        'where' => 
        array (
        ),
        'as' => 'generated::U75Lcx4yRsNcIu7F',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::lhgWvy2BluTMdxYZ' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/purchase-orders/cancel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\PurchaseOrdersController@cancelOrder',
        'controller' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\PurchaseOrdersController@cancelOrder',
        'namespace' => NULL,
        'prefix' => 'api/purchase-orders',
        'where' => 
        array (
        ),
        'as' => 'generated::lhgWvy2BluTMdxYZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::mjpsaLEJ2YlsC2f7' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/purchase-orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\PurchaseOrdersController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\PurchaseOrdersController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/purchase-orders',
        'where' => 
        array (
        ),
        'as' => 'generated::mjpsaLEJ2YlsC2f7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::6F5EiPDeGxmSm1sF' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/purchase-orders/products',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\PurchaseOrdersController@deleteProducts',
        'controller' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\PurchaseOrdersController@deleteProducts',
        'namespace' => NULL,
        'prefix' => 'api/purchase-orders',
        'where' => 
        array (
        ),
        'as' => 'generated::6F5EiPDeGxmSm1sF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::GKmXfxmR49yuqaKY' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/purchase-orders/mail-supplier',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\PurchaseOrdersController@sendMailToSupplier',
        'controller' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\PurchaseOrdersController@sendMailToSupplier',
        'namespace' => NULL,
        'prefix' => 'api/purchase-orders',
        'where' => 
        array (
        ),
        'as' => 'generated::GKmXfxmR49yuqaKY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::yD4wE4XghP3bd7zm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/bad-orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\BadOrdersController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\BadOrdersController@index',
        'namespace' => NULL,
        'prefix' => 'api/bad-orders',
        'where' => 
        array (
        ),
        'as' => 'generated::yD4wE4XghP3bd7zm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::tGWnB7RCR8wZviwh' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/bad-orders/purchase-orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\BadOrdersController@indexPurchaseOrders',
        'controller' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\BadOrdersController@indexPurchaseOrders',
        'namespace' => NULL,
        'prefix' => 'api/bad-orders',
        'where' => 
        array (
        ),
        'as' => 'generated::tGWnB7RCR8wZviwh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::NVH8jzvJz7VFx57m' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/bad-orders/purchase-order',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\BadOrdersController@showPurchaseOrder',
        'controller' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\BadOrdersController@showPurchaseOrder',
        'namespace' => NULL,
        'prefix' => 'api/bad-orders',
        'where' => 
        array (
        ),
        'as' => 'generated::NVH8jzvJz7VFx57m',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::49PruAg0ssBBIdd9' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/bad-orders/details',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\BadOrdersController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\BadOrdersController@show',
        'namespace' => NULL,
        'prefix' => 'api/bad-orders',
        'where' => 
        array (
        ),
        'as' => 'generated::49PruAg0ssBBIdd9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::VeOwxGTtKT7vzpR0' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/bad-orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\BadOrdersController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\BadOrdersController@store',
        'namespace' => NULL,
        'prefix' => 'api/bad-orders',
        'where' => 
        array (
        ),
        'as' => 'generated::VeOwxGTtKT7vzpR0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::zZgQEGB4XHtambh8' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/bad-orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\BadOrdersController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\BadOrdersController@update',
        'namespace' => NULL,
        'prefix' => 'api/bad-orders',
        'where' => 
        array (
        ),
        'as' => 'generated::zZgQEGB4XHtambh8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::bhw4StaG8kT5nLNM' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/bad-orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\BadOrdersController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\InventoryManagement\\BadOrdersController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/bad-orders',
        'where' => 
        array (
        ),
        'as' => 'generated::bhw4StaG8kT5nLNM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::6kpoME6NuF3oVrGm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/customers',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Customer\\CustomersController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\Customer\\CustomersController@index',
        'namespace' => NULL,
        'prefix' => 'api/customers',
        'where' => 
        array (
        ),
        'as' => 'generated::6kpoME6NuF3oVrGm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::nL2rre2oAbcp56h0' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/customers/details',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Customer\\CustomersController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\Customer\\CustomersController@show',
        'namespace' => NULL,
        'prefix' => 'api/customers',
        'where' => 
        array (
        ),
        'as' => 'generated::nL2rre2oAbcp56h0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::2Wzr2uVyKH9EYHty' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/customers',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Customer\\CustomersController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\Customer\\CustomersController@store',
        'namespace' => NULL,
        'prefix' => 'api/customers',
        'where' => 
        array (
        ),
        'as' => 'generated::2Wzr2uVyKH9EYHty',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::5MuBA2guKTKMfOD6' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/customers',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Customer\\CustomersController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\Customer\\CustomersController@update',
        'namespace' => NULL,
        'prefix' => 'api/customers',
        'where' => 
        array (
        ),
        'as' => 'generated::5MuBA2guKTKMfOD6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::1kP6X3EL16vRPfsQ' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/customers',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Customer\\CustomersController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\Customer\\CustomersController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/customers',
        'where' => 
        array (
        ),
        'as' => 'generated::1kP6X3EL16vRPfsQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::7e5CggF7H0KTetQd' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/access-rights',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Employee\\AccessRightsController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\Employee\\AccessRightsController@index',
        'namespace' => NULL,
        'prefix' => 'api/access-rights',
        'where' => 
        array (
        ),
        'as' => 'generated::7e5CggF7H0KTetQd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::SMekl7MU7kYGO007' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/access-rights/details',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Employee\\AccessRightsController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\Employee\\AccessRightsController@show',
        'namespace' => NULL,
        'prefix' => 'api/access-rights',
        'where' => 
        array (
        ),
        'as' => 'generated::SMekl7MU7kYGO007',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::oeqh2wQYdvZYmb5y' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/access-rights',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Employee\\AccessRightsController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\Employee\\AccessRightsController@store',
        'namespace' => NULL,
        'prefix' => 'api/access-rights',
        'where' => 
        array (
        ),
        'as' => 'generated::oeqh2wQYdvZYmb5y',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::qEKcPhj0unLhuRYE' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/access-rights',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Employee\\AccessRightsController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\Employee\\AccessRightsController@update',
        'namespace' => NULL,
        'prefix' => 'api/access-rights',
        'where' => 
        array (
        ),
        'as' => 'generated::qEKcPhj0unLhuRYE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::JVg6vvzkX1ArLcru' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/access-rights',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Employee\\AccessRightsController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\Employee\\AccessRightsController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/access-rights',
        'where' => 
        array (
        ),
        'as' => 'generated::JVg6vvzkX1ArLcru',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::2gQOxgrCJsJnzHMd' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/employees',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Employee\\EmployeesController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\Employee\\EmployeesController@index',
        'namespace' => NULL,
        'prefix' => 'api/employees',
        'where' => 
        array (
        ),
        'as' => 'generated::2gQOxgrCJsJnzHMd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::SZ66mVsqjsydEOH7' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/employees/access_rights',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Employee\\EmployeesController@employeeAccessRights',
        'controller' => 'App\\Http\\Controllers\\Api\\Employee\\EmployeesController@employeeAccessRights',
        'namespace' => NULL,
        'prefix' => 'api/employees',
        'where' => 
        array (
        ),
        'as' => 'generated::SZ66mVsqjsydEOH7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::rEMNPUZYlWcOIWRV' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/employees/details',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Employee\\EmployeesController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\Employee\\EmployeesController@show',
        'namespace' => NULL,
        'prefix' => 'api/employees',
        'where' => 
        array (
        ),
        'as' => 'generated::rEMNPUZYlWcOIWRV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::lABvnN5WNGYTKz5b' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/employees',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Employee\\EmployeesController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\Employee\\EmployeesController@store',
        'namespace' => NULL,
        'prefix' => 'api/employees',
        'where' => 
        array (
        ),
        'as' => 'generated::lABvnN5WNGYTKz5b',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::aky783XmjMBPSnGF' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/employees',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Employee\\EmployeesController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\Employee\\EmployeesController@update',
        'namespace' => NULL,
        'prefix' => 'api/employees',
        'where' => 
        array (
        ),
        'as' => 'generated::aky783XmjMBPSnGF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::oUF9nLIkUK4Y21Jd' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/employees',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Employee\\EmployeesController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\Employee\\EmployeesController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/employees',
        'where' => 
        array (
        ),
        'as' => 'generated::oUF9nLIkUK4Y21Jd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::zr7OO5nHEni8Xa1D' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/pos/order-lists',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Pos\\PosController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\Pos\\PosController@index',
        'namespace' => NULL,
        'prefix' => 'api/pos',
        'where' => 
        array (
        ),
        'as' => 'generated::zr7OO5nHEni8Xa1D',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::QCfmHzhd4Buk75zz' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/pos/categories',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Pos\\PosController@categoriesIndex',
        'controller' => 'App\\Http\\Controllers\\Api\\Pos\\PosController@categoriesIndex',
        'namespace' => NULL,
        'prefix' => 'api/pos',
        'where' => 
        array (
        ),
        'as' => 'generated::QCfmHzhd4Buk75zz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::wDNiUx4yrSLD4C2K' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/pos/customers',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Pos\\PosController@customerIndex',
        'controller' => 'App\\Http\\Controllers\\Api\\Pos\\PosController@customerIndex',
        'namespace' => NULL,
        'prefix' => 'api/pos',
        'where' => 
        array (
        ),
        'as' => 'generated::wDNiUx4yrSLD4C2K',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::qvWelTwK43lKxxfi' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/pos/customer',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Pos\\PosController@showCustomer',
        'controller' => 'App\\Http\\Controllers\\Api\\Pos\\PosController@showCustomer',
        'namespace' => NULL,
        'prefix' => 'api/pos',
        'where' => 
        array (
        ),
        'as' => 'generated::qvWelTwK43lKxxfi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::e9K1zb29OVDH1dhh' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/pos/discounts',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Pos\\PosController@discountIndex',
        'controller' => 'App\\Http\\Controllers\\Api\\Pos\\PosController@discountIndex',
        'namespace' => NULL,
        'prefix' => 'api/pos',
        'where' => 
        array (
        ),
        'as' => 'generated::e9K1zb29OVDH1dhh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Gh278TPbdpvVPqXf' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/pos/products',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Pos\\PosController@productsIndex',
        'controller' => 'App\\Http\\Controllers\\Api\\Pos\\PosController@productsIndex',
        'namespace' => NULL,
        'prefix' => 'api/pos',
        'where' => 
        array (
        ),
        'as' => 'generated::Gh278TPbdpvVPqXf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::FRnIiicQ4mUW4rru' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/pos/order-lists/filtered',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Pos\\PosController@indexFiltered',
        'controller' => 'App\\Http\\Controllers\\Api\\Pos\\PosController@indexFiltered',
        'namespace' => NULL,
        'prefix' => 'api/pos',
        'where' => 
        array (
        ),
        'as' => 'generated::FRnIiicQ4mUW4rru',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::zsZBNlduREa3zvAF' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/pos/cart-details',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Pos\\PosController@showCartDetails',
        'controller' => 'App\\Http\\Controllers\\Api\\Pos\\PosController@showCartDetails',
        'namespace' => NULL,
        'prefix' => 'api/pos',
        'where' => 
        array (
        ),
        'as' => 'generated::zsZBNlduREa3zvAF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::mRrbdzG3X4VUMfZU' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/pos/add-to-cart',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Pos\\PosController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\Pos\\PosController@store',
        'namespace' => NULL,
        'prefix' => 'api/pos',
        'where' => 
        array (
        ),
        'as' => 'generated::mRrbdzG3X4VUMfZU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::h3Lz6UKvfnBLyoPP' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/pos/to-pay',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Pos\\PosController@showAmountToPay',
        'controller' => 'App\\Http\\Controllers\\Api\\Pos\\PosController@showAmountToPay',
        'namespace' => NULL,
        'prefix' => 'api/pos',
        'where' => 
        array (
        ),
        'as' => 'generated::h3Lz6UKvfnBLyoPP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::AaFJpnLGnLqk4QRa' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/pos/process-payment',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Pos\\PosController@processPayment',
        'controller' => 'App\\Http\\Controllers\\Api\\Pos\\PosController@processPayment',
        'namespace' => NULL,
        'prefix' => 'api/pos',
        'where' => 
        array (
        ),
        'as' => 'generated::AaFJpnLGnLqk4QRa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Sw7DvxhPJmCvX3dI' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/pos/discount-all',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Pos\\PosController@assignDiscountToAll',
        'controller' => 'App\\Http\\Controllers\\Api\\Pos\\PosController@assignDiscountToAll',
        'namespace' => NULL,
        'prefix' => 'api/pos',
        'where' => 
        array (
        ),
        'as' => 'generated::Sw7DvxhPJmCvX3dI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::LXZ2SrvFMoC7yW4J' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/pos/discount/item-quantity',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Pos\\PosController@applyDiscountAddQuantity',
        'controller' => 'App\\Http\\Controllers\\Api\\Pos\\PosController@applyDiscountAddQuantity',
        'namespace' => NULL,
        'prefix' => 'api/pos',
        'where' => 
        array (
        ),
        'as' => 'generated::LXZ2SrvFMoC7yW4J',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::CjsntNRAFTQ4RU5p' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/pos/cancel-orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Pos\\PosController@cancelOrders',
        'controller' => 'App\\Http\\Controllers\\Api\\Pos\\PosController@cancelOrders',
        'namespace' => NULL,
        'prefix' => 'api/pos',
        'where' => 
        array (
        ),
        'as' => 'generated::CjsntNRAFTQ4RU5p',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::xEKLyyVNxKmjE9GN' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/pos/discount-all',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Pos\\PosController@removeDiscountToAll',
        'controller' => 'App\\Http\\Controllers\\Api\\Pos\\PosController@removeDiscountToAll',
        'namespace' => NULL,
        'prefix' => 'api/pos',
        'where' => 
        array (
        ),
        'as' => 'generated::xEKLyyVNxKmjE9GN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::fdRfoafKs0OUggzu' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/pos/items',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Pos\\PosController@removeItems',
        'controller' => 'App\\Http\\Controllers\\Api\\Pos\\PosController@removeItems',
        'namespace' => NULL,
        'prefix' => 'api/pos',
        'where' => 
        array (
        ),
        'as' => 'generated::fdRfoafKs0OUggzu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::aeDzAV4IDM8NOK1X' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/receipts',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Receipt\\ReceiptsController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\Receipt\\ReceiptsController@index',
        'namespace' => NULL,
        'prefix' => 'api/receipts',
        'where' => 
        array (
        ),
        'as' => 'generated::aeDzAV4IDM8NOK1X',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::yqWmHkPNvZRiMafr' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/receipts/with-details',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Receipt\\ReceiptsController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\Receipt\\ReceiptsController@show',
        'namespace' => NULL,
        'prefix' => 'api/receipts',
        'where' => 
        array (
        ),
        'as' => 'generated::yqWmHkPNvZRiMafr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::oVSol5qDUHwZQ8ha' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/invoices',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Invoice\\InvoiceController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\Invoice\\InvoiceController@index',
        'namespace' => NULL,
        'prefix' => 'api/invoices',
        'where' => 
        array (
        ),
        'as' => 'generated::oVSol5qDUHwZQ8ha',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::oBWSPOnT9MFqGDYr' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/invoices/details',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Invoice\\InvoiceController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\Invoice\\InvoiceController@show',
        'namespace' => NULL,
        'prefix' => 'api/invoices',
        'where' => 
        array (
        ),
        'as' => 'generated::oBWSPOnT9MFqGDYr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::oXKushkXFoW2iTpz' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/invoices',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Invoice\\InvoiceController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\Invoice\\InvoiceController@update',
        'namespace' => NULL,
        'prefix' => 'api/invoices',
        'where' => 
        array (
        ),
        'as' => 'generated::oXKushkXFoW2iTpz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::P2Pk87rXzVSLgpKV' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/invoices',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Invoice\\InvoiceController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\Invoice\\InvoiceController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/invoices',
        'where' => 
        array (
        ),
        'as' => 'generated::P2Pk87rXzVSLgpKV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::caCHUSq33sAwtKLl' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/sales-returns',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SalesReturn\\SalesReturnController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\SalesReturn\\SalesReturnController@index',
        'namespace' => NULL,
        'prefix' => 'api/sales-returns',
        'where' => 
        array (
        ),
        'as' => 'generated::caCHUSq33sAwtKLl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::m24kdOtMgtn8k2lS' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/sales-returns/customer-orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SalesReturn\\SalesReturnController@indexWithOrders',
        'controller' => 'App\\Http\\Controllers\\Api\\SalesReturn\\SalesReturnController@indexWithOrders',
        'namespace' => NULL,
        'prefix' => 'api/sales-returns',
        'where' => 
        array (
        ),
        'as' => 'generated::m24kdOtMgtn8k2lS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::eTtrL75S0pEQ2BEV' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/sales-returns/customer-order',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SalesReturn\\SalesReturnController@showForSalesReturn',
        'controller' => 'App\\Http\\Controllers\\Api\\SalesReturn\\SalesReturnController@showForSalesReturn',
        'namespace' => NULL,
        'prefix' => 'api/sales-returns',
        'where' => 
        array (
        ),
        'as' => 'generated::eTtrL75S0pEQ2BEV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::36EPg9rI4jcD9LZc' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/sales-returns/details',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SalesReturn\\SalesReturnController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\SalesReturn\\SalesReturnController@show',
        'namespace' => NULL,
        'prefix' => 'api/sales-returns',
        'where' => 
        array (
        ),
        'as' => 'generated::36EPg9rI4jcD9LZc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::PVh1k8ESodtlEKhu' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/sales-returns',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SalesReturn\\SalesReturnController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\SalesReturn\\SalesReturnController@store',
        'namespace' => NULL,
        'prefix' => 'api/sales-returns',
        'where' => 
        array (
        ),
        'as' => 'generated::PVh1k8ESodtlEKhu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::5WTyiUKtk4CxKbkI' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/sales-returns',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SalesReturn\\SalesReturnController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\SalesReturn\\SalesReturnController@update',
        'namespace' => NULL,
        'prefix' => 'api/sales-returns',
        'where' => 
        array (
        ),
        'as' => 'generated::5WTyiUKtk4CxKbkI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ODu4aobmbFJdCTOe' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/sales-returns',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SalesReturn\\SalesReturnController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\SalesReturn\\SalesReturnController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/sales-returns',
        'where' => 
        array (
        ),
        'as' => 'generated::ODu4aobmbFJdCTOe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::hAB1fBE068kInvJo' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/sales-returns/items',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SalesReturn\\SalesReturnController@removeItems',
        'controller' => 'App\\Http\\Controllers\\Api\\SalesReturn\\SalesReturnController@removeItems',
        'namespace' => NULL,
        'prefix' => 'api/sales-returns',
        'where' => 
        array (
        ),
        'as' => 'generated::hAB1fBE068kInvJo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::jGyzhJV7SrAZlVEs' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/transactions/customer-orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Transactions\\TransactionsController@customerOrderTransactions',
        'controller' => 'App\\Http\\Controllers\\Api\\Transactions\\TransactionsController@customerOrderTransactions',
        'namespace' => NULL,
        'prefix' => 'api/transactions',
        'where' => 
        array (
        ),
        'as' => 'generated::jGyzhJV7SrAZlVEs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::oUcumXidCforXuAj' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/transactions/invoices',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Transactions\\TransactionsController@invoiceTransactions',
        'controller' => 'App\\Http\\Controllers\\Api\\Transactions\\TransactionsController@invoiceTransactions',
        'namespace' => NULL,
        'prefix' => 'api/transactions',
        'where' => 
        array (
        ),
        'as' => 'generated::oUcumXidCforXuAj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::sW6uwKs7E2huIXYv' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/transactions/purchase-orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Transactions\\TransactionsController@purchaseOrderTransactions',
        'controller' => 'App\\Http\\Controllers\\Api\\Transactions\\TransactionsController@purchaseOrderTransactions',
        'namespace' => NULL,
        'prefix' => 'api/transactions',
        'where' => 
        array (
        ),
        'as' => 'generated::sW6uwKs7E2huIXYv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::q0skXjAY9w1UP4Gg' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/transactions/received-stocks',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Transactions\\TransactionsController@receivedStocksTransactions',
        'controller' => 'App\\Http\\Controllers\\Api\\Transactions\\TransactionsController@receivedStocksTransactions',
        'namespace' => NULL,
        'prefix' => 'api/transactions',
        'where' => 
        array (
        ),
        'as' => 'generated::q0skXjAY9w1UP4Gg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::eyOiM2BpKREzHmnB' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/reports/general',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Reports\\ReportsController@generalAnalytics',
        'controller' => 'App\\Http\\Controllers\\Api\\Reports\\ReportsController@generalAnalytics',
        'namespace' => NULL,
        'prefix' => 'api/reports',
        'where' => 
        array (
        ),
        'as' => 'generated::eyOiM2BpKREzHmnB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::lzrwXv8rw0BHl4zK' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/reports/sales-by-item',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Reports\\ReportsController@getSalesByItemReports',
        'controller' => 'App\\Http\\Controllers\\Api\\Reports\\ReportsController@getSalesByItemReports',
        'namespace' => NULL,
        'prefix' => 'api/reports',
        'where' => 
        array (
        ),
        'as' => 'generated::lzrwXv8rw0BHl4zK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::3TAcigGLQ11k9l7p' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/reports/sales-by-category',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Reports\\ReportsController@getSalesByCategory',
        'controller' => 'App\\Http\\Controllers\\Api\\Reports\\ReportsController@getSalesByCategory',
        'namespace' => NULL,
        'prefix' => 'api/reports',
        'where' => 
        array (
        ),
        'as' => 'generated::3TAcigGLQ11k9l7p',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::qRCZlmPcbRE2hXiF' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/reports/sales-by-payment-type',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Reports\\ReportsController@getSalesByPaymentType',
        'controller' => 'App\\Http\\Controllers\\Api\\Reports\\ReportsController@getSalesByPaymentType',
        'namespace' => NULL,
        'prefix' => 'api/reports',
        'where' => 
        array (
        ),
        'as' => 'generated::qRCZlmPcbRE2hXiF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::MK4gMYZAcdczp2qg' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/reports/sales-by-employee',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Reports\\ReportsController@getSalesByEmployee',
        'controller' => 'App\\Http\\Controllers\\Api\\Reports\\ReportsController@getSalesByEmployee',
        'namespace' => NULL,
        'prefix' => 'api/reports',
        'where' => 
        array (
        ),
        'as' => 'generated::MK4gMYZAcdczp2qg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::XPqSPo1kNi8sOGSE' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/pdf-print/sales-receipt/{sale}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ExportControllers\\ExportSalesController@print',
        'controller' => 'App\\Http\\Controllers\\Api\\ExportControllers\\ExportSalesController@print',
        'namespace' => NULL,
        'prefix' => 'api/pdf-print',
        'where' => 
        array (
        ),
        'as' => 'generated::XPqSPo1kNi8sOGSE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::g6h3DXgZ1NonDQlg' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/pdf-export/invoices/{invoice}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ExportControllers\\ExportInvoiceController@toPDF',
        'controller' => 'App\\Http\\Controllers\\Api\\ExportControllers\\ExportInvoiceController@toPDF',
        'namespace' => NULL,
        'prefix' => 'api/pdf-export',
        'where' => 
        array (
        ),
        'as' => 'generated::g6h3DXgZ1NonDQlg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::nToOEqEMNxdffDv6' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/pdf-export/purchase-order/{purchaseOrder}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ExportControllers\\ExportPurchaseOrdersController@toPDF',
        'controller' => 'App\\Http\\Controllers\\Api\\ExportControllers\\ExportPurchaseOrdersController@toPDF',
        'namespace' => NULL,
        'prefix' => 'api/pdf-export',
        'where' => 
        array (
        ),
        'as' => 'generated::nToOEqEMNxdffDv6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ygJ5eKcLCCK4aKKN' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/pdf-export/pos-payment/{payment}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ExportControllers\\ExportPaymentsController@toPDF',
        'controller' => 'App\\Http\\Controllers\\Api\\ExportControllers\\ExportPaymentsController@toPDF',
        'namespace' => NULL,
        'prefix' => 'api/pdf-export',
        'where' => 
        array (
        ),
        'as' => 'generated::ygJ5eKcLCCK4aKKN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::dWeHPT9g4t3rIBiA' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/excel-export/invoices',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ExportControllers\\ExportInvoiceController@toExcel',
        'controller' => 'App\\Http\\Controllers\\Api\\ExportControllers\\ExportInvoiceController@toExcel',
        'namespace' => NULL,
        'prefix' => 'api/excel-export',
        'where' => 
        array (
        ),
        'as' => 'generated::dWeHPT9g4t3rIBiA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::U99df2olj1sVHEVe' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/excel-export/purchase-orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ExportControllers\\ExportPurchaseOrdersController@toExcel',
        'controller' => 'App\\Http\\Controllers\\Api\\ExportControllers\\ExportPurchaseOrdersController@toExcel',
        'namespace' => NULL,
        'prefix' => 'api/excel-export',
        'where' => 
        array (
        ),
        'as' => 'generated::U99df2olj1sVHEVe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::OUY6CAnWKjcA96xn' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/excel-export/payments',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ExportControllers\\ExportPaymentsController@toExcel',
        'controller' => 'App\\Http\\Controllers\\Api\\ExportControllers\\ExportPaymentsController@toExcel',
        'namespace' => NULL,
        'prefix' => 'api/excel-export',
        'where' => 
        array (
        ),
        'as' => 'generated::OUY6CAnWKjcA96xn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::kHFirSDvtexRdo8j' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/excel-export/customers',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ExportControllers\\ExportCustomersController@toExcel',
        'controller' => 'App\\Http\\Controllers\\Api\\ExportControllers\\ExportCustomersController@toExcel',
        'namespace' => NULL,
        'prefix' => 'api/excel-export',
        'where' => 
        array (
        ),
        'as' => 'generated::kHFirSDvtexRdo8j',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ZULomzY50yUWguh5' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/excel-export/products',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ExportControllers\\ExportProductsController@toExcel',
        'controller' => 'App\\Http\\Controllers\\Api\\ExportControllers\\ExportProductsController@toExcel',
        'namespace' => NULL,
        'prefix' => 'api/excel-export',
        'where' => 
        array (
        ),
        'as' => 'generated::ZULomzY50yUWguh5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::eAUWMyfcxUYURpao' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/excel-export/bad-orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ExportControllers\\ExportBadOrdersController@toExcel',
        'controller' => 'App\\Http\\Controllers\\Api\\ExportControllers\\ExportBadOrdersController@toExcel',
        'namespace' => NULL,
        'prefix' => 'api/excel-export',
        'where' => 
        array (
        ),
        'as' => 'generated::eAUWMyfcxUYURpao',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::vM1JROXjq0Ggwqya' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/excel-export/sales-returns',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ExportControllers\\ExportSalesReturnController@toExcel',
        'controller' => 'App\\Http\\Controllers\\Api\\ExportControllers\\ExportSalesReturnController@toExcel',
        'namespace' => NULL,
        'prefix' => 'api/excel-export',
        'where' => 
        array (
        ),
        'as' => 'generated::vM1JROXjq0Ggwqya',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::33g41Kp1VlbTF8nj' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/csv-export/invoices',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ExportControllers\\ExportInvoiceController@toCSV',
        'controller' => 'App\\Http\\Controllers\\Api\\ExportControllers\\ExportInvoiceController@toCSV',
        'namespace' => NULL,
        'prefix' => 'api/csv-export',
        'where' => 
        array (
        ),
        'as' => 'generated::33g41Kp1VlbTF8nj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::XPyhzylYI6bpXGT4' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/csv-export/purchase-orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ExportControllers\\ExportPurchaseOrdersController@toCSV',
        'controller' => 'App\\Http\\Controllers\\Api\\ExportControllers\\ExportPurchaseOrdersController@toCSV',
        'namespace' => NULL,
        'prefix' => 'api/csv-export',
        'where' => 
        array (
        ),
        'as' => 'generated::XPyhzylYI6bpXGT4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::MC50M8EtG6simGx7' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/csv-export/purchase-order/{purchaseOrder}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ExportControllers\\ExportPurchaseOrdersController@purchaseOrderToCSV',
        'controller' => 'App\\Http\\Controllers\\Api\\ExportControllers\\ExportPurchaseOrdersController@purchaseOrderToCSV',
        'namespace' => NULL,
        'prefix' => 'api/csv-export',
        'where' => 
        array (
        ),
        'as' => 'generated::MC50M8EtG6simGx7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Gc9yh62yYdMvY0IX' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/csv-export/payments',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ExportControllers\\ExportPaymentsController@toCSV',
        'controller' => 'App\\Http\\Controllers\\Api\\ExportControllers\\ExportPaymentsController@toCSV',
        'namespace' => NULL,
        'prefix' => 'api/csv-export',
        'where' => 
        array (
        ),
        'as' => 'generated::Gc9yh62yYdMvY0IX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::itndjTiRXN9LrI36' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/csv-export/customers',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ExportControllers\\ExportCustomersController@toCSV',
        'controller' => 'App\\Http\\Controllers\\Api\\ExportControllers\\ExportCustomersController@toCSV',
        'namespace' => NULL,
        'prefix' => 'api/csv-export',
        'where' => 
        array (
        ),
        'as' => 'generated::itndjTiRXN9LrI36',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::vVXRR6rJp4ZZZw9k' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/csv-export/products',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ExportControllers\\ExportProductsController@toCSV',
        'controller' => 'App\\Http\\Controllers\\Api\\ExportControllers\\ExportProductsController@toCSV',
        'namespace' => NULL,
        'prefix' => 'api/csv-export',
        'where' => 
        array (
        ),
        'as' => 'generated::vVXRR6rJp4ZZZw9k',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Ut6ni5tw47QRNKnm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/csv-export/bad-orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ExportControllers\\ExportBadOrdersController@toCSV',
        'controller' => 'App\\Http\\Controllers\\Api\\ExportControllers\\ExportBadOrdersController@toCSV',
        'namespace' => NULL,
        'prefix' => 'api/csv-export',
        'where' => 
        array (
        ),
        'as' => 'generated::Ut6ni5tw47QRNKnm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::88OadaUSlcqCya1I' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/csv-export/sales-returns',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ExportControllers\\ExportSalesReturnController@toCSV',
        'controller' => 'App\\Http\\Controllers\\Api\\ExportControllers\\ExportSalesReturnController@toCSV',
        'namespace' => NULL,
        'prefix' => 'api/csv-export',
        'where' => 
        array (
        ),
        'as' => 'generated::88OadaUSlcqCya1I',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::CJkQj7qh008WHdsC' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/import/products',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Imports\\ImportProductsController@import',
        'controller' => 'App\\Http\\Controllers\\Api\\Imports\\ImportProductsController@import',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::CJkQj7qh008WHdsC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::f39dHfwHlLs30UiD' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'C:32:"Opis\\Closure\\SerializableClosure":258:{@tLE5bjrs41Vaxu68kIvl77PgDoMnLwh8gK8Rs6gR4lc=.a:5:{s:3:"use";a:0:{}s:8:"function";s:46:"function () {
    return \\view(\'welcome\');
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000007578a3fa000000006d60160c";}}',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::f39dHfwHlLs30UiD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
  ),
)
);
